<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Models\Waysend;

class RemoveOTP extends Command {
    protected $signature = 'RemoveOTP';
    protected $description = 'Melakukan perintah untuk membersihkan OTP dalam 1 Menit sekali.';
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function handle() {
        $user = new User();
        $user->kode_otp = NULL;
        $user->save;
    }
}