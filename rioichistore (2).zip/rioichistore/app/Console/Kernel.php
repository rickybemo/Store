<?php

namespace App\Console;
use Illuminate\Support\Facades\Log;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
     
     protected $commands = [
       \App\Console\Commands\updatePembelian::class,
       \App\Console\Commands\getCategories::class,
       \App\Console\Commands\updatePesanan::class,
       \App\Console\Commands\getService::class,
       \App\Console\Commands\RemoveOTP::class,
     ];

    
    protected function schedule(Schedule $schedule)
    {
        $schedule->call(function () {
            Log::info('Cronjob berhasil dijalankan');
        })->everyMinute();
        
        $schedule->command('updatePesanan')->everyMinute();
        $schedule->command('updatePembelian')->everyMinute();
        $schedule->command('getCategories')->everyMinute();
        $schedule->command('getService')->everyMinute();
        $schedule->command('RemoveOTP')->everyFiveMinutes();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
