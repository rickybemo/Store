<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Waysend;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function create()
    {
        return view('components.admin.login');
    }

    public function store(Request $request)
    {
        $credential = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);
        
        $checkUsers = User::where("username", $request->username)->count();
        if($checkUsers == 0) {
            return back()->with('error', 'Tidak ada kecocokan data yang anda masukkan dengan Database kami!');
        } else {
            $is_verified = User::where("username", $request->username)->first();
            if($is_verified->is_verified == 0) {
                return redirect(route('otp', $request->username))->with('error', 'Lakukan verifikasi akun sebelum Login!');
            } else {
                if (Auth::attempt($credential)) {
                    $request->session()->regenerate();
        
                    return redirect()->intended('dashboard');
                }
                
                return back()->with('error', 'Tidak ada kecocokan data yang anda masukkan dengan Database kami!');
            }
        }
    }

    public function destroy(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }    
    
    public function forgot_index() {
        return view('components.admin.forgot');
    }
    
    public function forgot(Request $request) {
        $user = User::where("username", $request->username)->count();
        
        if($user == 0) {
            return back()->with('error', 'Tidak ada kecocokan data yang anda masukkan dengan Database kami!');
        } else {
            $users = User::where("username", $request->username)->first();
            $makeOTP = $this->generateRandomString(6);
        
            $users->kode_otp = password_hash($makeOTP, PASSWORD_BCRYPT);
            $users->save();
            
            $pesan = "Halo ".$users->username." gunakan link dibawah ini untuk melakukan Reset Password \n\n".ENV('APP_URL')."/reset-password/".Crypt::encryptString($makeOTP."&".$users->username)."\n\nJangan bagikan link ini pada siapapun!\n\n".ENV('APP_NAME');
            $this->msg($users->no_telepon, $pesan);
            
            return back()->with('msg', 'Success Lupa Password! Silahkan Cek Link yang dikirimkan lewat WhatsApp.');
        }
    }
    
    public function reset(Request $request, $id) {
        $Decrypt = Crypt::decryptString($id);
        $extract = explode("&", $Decrypt);
        
        $OTPCode  = $extract[0];
        $username = $extract[1];
        
        $user = User::where("username", $username)->count();
        if($user == 0) {
            return redirect(route('forgot'))->with('error', 'Link tidak valid / sudah kadaluarsa, silahkan lakukan Reset Password ulang.');
        } else {
            $users = User::where("username", $username)->first();
            if(password_verify($OTPCode, $users->kode_otp)) {
                return view('components.admin.resetpassword', ["username" => $users->username, "kode_otp" => $OTPCode]);
            } else {
                return redirect(route('forgot'))->with('error', 'Link tidak valid / sudah kadaluarsa, silahkan lakukan Reset Password ulang.');
            }
        }
    }
    
    public function resetstore(Request $request) {
        $credential = $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);
        
        $users = User::where("username", $request->username)->count();
        if($users == 0) {
            return back()->with('error', 'Username tidak ditemukan!');
        } else {
            $user = User::where("username", $request->username)->first();
            $user->password = Hash::make($request->password);
            $user->kode_otp = NULL;
            $user->save();
            
            return redirect(route('login'))->with('success', 'Reset password berhasil, silahkan login!');
        }
    }
    
    public function generateRandomString($length) {
        $characters = '0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    
    public function msg($nomor, $msg)
    {

        $waysender = Waysend::find(1);
        $data = [
            'api_key' => $waysender->key,
            'sender'  => $waysender->number,
            'number'  => "$nomor",
            'message' => "$msg"
        ];

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $waysender->api_url.'/send-message',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
    
    public function encryptIt( $q ) {
        $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
        $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
        return( $qEncoded );
    }
    
    public function decryptIt( $q ) {
        $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
        $qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
        return( $qDecoded );
    }
}
