<?php

namespace App\Http\Controllers;

use App\Models\ApiCheck;
use App\Models\Apigame;
use App\Models\Ipaymu;
use App\Models\Waysend;
use Illuminate\Http\Request;

class ConfigController extends Controller
{
    public function wasend()
    {
        $wasend = Waysend::find(1);
        return view('components.wasend', compact('wasend'));
    }
    public function wasendChange(Request $request)
    {
        $wasend = Waysend::find(1);
        if ($wasend) {
            $wasend->key = $request->key;
            $wasend->number = $request->number;
            $wasend->api_url = $request->api_url;
            $wasend->save();
            return redirect()->back()->with('success', 'Berhasil mengubah data');
        } else {
            return redirect()->back()->with('error', 'Gagal mengubah data');
        }
    }
    public function ipaymu()
    {
        $ipaymu = Ipaymu::find(1);
        return view('components.ipaymu', compact('ipaymu'));
    }
    public function ipaymuChange(Request $request)
    {
        $ipaymu = Ipaymu::find(1);
        if ($ipaymu) {
            $ipaymu->va = $request->va;
            $ipaymu->key = $request->key;
            $ipaymu->save();
            return redirect()->back()->with('success', 'Berhasil mengubah data');
        } else {
            return redirect()->back()->with('error', 'Gagal mengubah data');
        }
    }
    public function apigames()
    {
        $apigames = apigame::find(1);
        return view('components.apigames', compact('apigames'));
    }
    public function apigamesChange(Request $request)
    {
        $apigames = apigame::find(1);
        if ($apigames) {
            $apigames->secret = $request->secret;
            $apigames->merchant = $request->merchant;
            $apigames->save();
            return redirect()->back()->with('success', 'Berhasil mengubah data');
        } else {
            return redirect()->back()->with('error', 'Gagal mengubah data');
        }
    }
    public function ApiCheck()
    {
        $rioichi = ApiCheck::where('provider', 'rioichi')->first();
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        return view('components.apiCheck', compact('rioichi', 'lolhuman'));
    }
    public function ApiCheckChange(Request $request)
    {
        $rioichi = ApiCheck::where('provider', 'rioichi')->first();
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $rioichi->key = $request->rioichi;
        $lolhuman->key = $request->lolhuman;
        $rioichi->save();
        $lolhuman->save();
        return redirect()->back()->with('success', 'Berhasil mengubah data');
    }
}
