<?php

namespace App\Http\Controllers;

use App\Models\ApiCheck;
use Illuminate\Http\Request;

class DuniaGames extends Controller
{
    public function mobile_legends($user_id, $server_id)
    {
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.lolhuman.xyz/api/mobilelegend/$user_id/$server_id?apikey=" . $lolhuman->key,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95", "Accept: application/json"],
        ]);

        $response = curl_exec($curl);
        $response = json_decode($response);
        curl_close($curl);
        if ($response->status == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $response->result],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function genshin_impact($user_id)
    {
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.lolhuman.xyz/api/genshin/username/$user_id?apikey=" . $lolhuman->key,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95", "Accept: application/json"],
        ]);

        $response = curl_exec($curl);
        $response = json_decode($response);
        curl_close($curl);
        if ($response->status == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $response->result],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function codm($user_id)
    {
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.lolhuman.xyz/api/codm/$user_id?apikey=" . $lolhuman->key,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95", "Accept: application/json"],
        ]);

        $response = curl_exec($curl);
        $response = json_decode($response);
        curl_close($curl);
        if ($response->status == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $response->result],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function higgh_domino($user_id)
    {
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.lolhuman.xyz/api/higghdomino/$user_id?apikey=" . $lolhuman->key,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95", "Accept: application/json"],
        ]);

        $response = curl_exec($curl);
        $response = json_decode($response);
        curl_close($curl);
        if ($response->status == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $response->result],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function freefire($user_id)
    {
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.lolhuman.xyz/api/freefire/$user_id?apikey=" . $lolhuman->key,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95", "Accept: application/json"],
        ]);

        $response = curl_exec($curl);
        $response = json_decode($response);
        curl_close($curl);
        if ($response->status == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $response->result],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function pubg($user_id)
    {
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.lolhuman.xyz/api/pubg/$user_id?apikey=" . $lolhuman->key,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95", "Accept: application/json"],
        ]);

        $response = curl_exec($curl);
        $response = json_decode($response);
        curl_close($curl);
        if ($response->status == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $response->result],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function sausageman($user_id)
    {
        $lolhuman = ApiCheck::where('provider', 'lolhuman')->first();
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => "https://api.lolhuman.xyz/api/sausageman/$user_id?apikey=" . $lolhuman->key,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 OPR/91.0.4516.95", "Accept: application/json"],
        ]);

        $response = curl_exec($curl);
        $response = json_decode($response);
        curl_close($curl);
        if ($response->status == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $response->result],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function check($user_id = null, $zone_id = null, $game = null)
    {
        $params = [
            "api_key" => ENV("YMAPI"),
            "game" => $game,
            "user_id" => $user_id,
            "zone_id" => $zone_id,
        ];

        $result = $this->connect($params);
        // dd(ENV("YMAPI"));
        // dd($result);
        if ($result["code"] == 200) {
            return [
                "status" => ["code" => 200],
                "data" => ["userNameGame" => $result["result"]["username"]],
            ];
        } else {
            return [
                "status" => ["code" => 1],
            ];
        }
    }

    public function connect($data = null)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.lolhuman.xyz/api/mobilelegend/84830127/2169?apikey=jancukapikeyapik");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

        $chresult = curl_exec($ch);
        curl_close($ch);
        $json_result = json_decode($chresult, true);
        return $json_result;
    }
}
