<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kategori;

class KategoriController extends Controller
{
    public function create()
    {
        return view('components.admin.kategori', ['data' => Kategori::orderBy('nama', 'asc')->paginate(10)]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'thumbnail' => 'required|file|mimes:jpg,png',
            'petunjuk' => 'required|file|mimes:jpg,png',
            'nama' => 'required',
            'kode' => 'required|unique:kategoris,kode',
            'publisher' => 'required',
            'serverOption' => 'required',
            'jumlah' => 'required',
            'tipe' => 'required'
        ]);

        $file = $request->file('thumbnail');
        $folder = 'assets/thumbnail';
        $file->move($folder, $file->getClientOriginalName());

        $petunjuk = $request->file('petunjuk');
        $folderPetunjuk = 'assets/petunjuk';
        $petunjuk->move($folderPetunjuk, $petunjuk->getClientOriginalName());

        $kategori = new Kategori();
        $kategori->nama = $request->nama;
        $kategori->kode = $request->kode;
        $kategori->publisher = $request->publisher;
        $kategori->server_id = $request->serverOption == 'ya' ? 1 : 0;
        $kategori->kolom_jumlah = $request->jumlah == "ya" ? 1 : 0;
        $kategori->tipe = $request->tipe;
        $kategori->thumbnail = "/" . $folder . "/" . $file->getClientOriginalName();
        $kategori->petunjuk = "/" . $folderPetunjuk . "/" . $petunjuk->getClientOriginalName();
        $kategori->save();

        return back()->with('success', 'Berhasil menambahkan kategori');
    }

    public function delete($id)
    {
        try {
            $data = Kategori::where('id', $id)->select('thumbnail')->first();
            unlink(public_path($data->thumbnail));
            unlink(public_path($data->petunjuk));
            Kategori::where('id', $id)->delete();
            return back()->with('success', 'Berhasil hapus!');
        } catch (\Exception $e) {
            Kategori::where('id', $id)->delete();
            return back()->with('success', 'Berhasil hapus!');
        }
    }

    public function update($id, $status)
    {
        $data = Kategori::where('id', $id)->update([
            'status' => $status
        ]);

        return back()->with('success', 'Berhasil update!');
    }

    public function detail($id)
    {
        $data = Kategori::where('id', $id)->first();

        $send = "
                <form action='" . route("kategori.detail.update", [$id]) . "' method='POST' enctype='multipart/form-data'>
                    <input type='hidden' name='_token' value='" . csrf_token() . "'>
                    <div class='mb-3 row'>
                        <label class='col-lg-2 col-form-label' for='example-fileinput'>Nama</label>
                        <div class='col-lg-10'>
                            <input type='text' class='form-control' value='" . $data->nama . "' name='kategori'>
                        </div>
                    </div>    
                         <div class='mb-3 row'>
                <label class='col-lg-2 col-form-label'>Tipe</label>
                <div class='col-lg-10'>
                    <select class='form-select' name='tipe'>
                       <option value='game'>Game</option>
                        <option value='ewallet'>E-Wallet</option>
                        <option value='Pulsa'>Pulsa</option>
                        <option value='joki'>Joki</option>
                        <option value='vilog'>Vilog</option>
                    </select>
                </div>
            </div>    
                    <div class='mb-3 row'>
                        <label class='col-lg-2 col-form-label' for='example-fileinput'>Kode</label>
                        <div class='col-lg-10'>
                            <input type='text' class='form-control' value='" . $data->kode . "' name='kode'>
                        </div>
                    </div>  
                    <div class='mb-3 row'>
                        <label class='col-lg-2 col-form-label' for='example-fileinput'>Publisher</label>
                        <div class='col-lg-10'>
                            <input type='text' class='form-control' value='" . $data->publisher . "' name='publisher'>
                        </div>
                    </div>  
                    <div class='mb-3 row'>
                        <label class='col-lg-2 col-form-label' for='example-fileinput'>Thumbnail</label>
                        <div class='col-lg-10'>
                            <input type='file' class='form-control' value='" . $data->thumbnail . "' name='thumbnail'>
                        </div>
                    </div>    
                    <div class='mb-3 row'>
                        <label class='col-lg-2 col-form-label' for='example-fileinput'>Petunjuk</label>
                        <div class='col-lg-10'>
                            <input type='file' class='form-control' value='" . $data->petunjuk . "' name='petunjuk'>
                        </div>
                    </div>                        
                         <div class='mb-3 row'>
                <label class='col-lg-2 col-form-label'>Sistem Target</label>
                <div class='col-lg-10'>
                    <select class='form-select' id='customRadio1' name='serverOption'>
                        <option value='tidak'>1 Target (User ID)</option>
                        <option value='ya'>2 Target (User ID / Server ID</option>
                    </select>
                </div>
            </div>
                    <div class='mb-3 row'>
                        <label class='col-lg-2 col-form-label' for='example-fileinput'>Status</label>
                        <div class='col-lg-10'>
                            <select class='form-control' name='status'>
                                <option value='active'>Active</option>
                                <option value='unactive'>Unactive</option>
                            </select>
                        </div>
                    </div>                    
                    <div class='modal-footer'>
                        <button type='button' class='btn btn-danger' data-bs-dismiss='modal'>Close</button>
                        <button type='submit' class='btn btn-primary'>Simpan</button>
                    </div>
                </form>
        ";

        return $send;
    }

    public function patch(Request $request, $id)
    {
        if ($request->file('thumbnail')) {
            $file = $request->file('thumbnail');
            $folder = 'assets/thumbnail';
            $file->move($folder, $file->getClientOriginalName());
            Kategori::where('id', $id)->update([
                'thumbnail' => "/" . $folder . "/" . $file->getClientOriginalName()
            ]);
        }

        if ($request->file('petunjuk')) {
            $file = $request->file('petunjuk');
            $folder = 'assets/petunjuk';
            $file->move($folder, $file->getClientOriginalName());
            Kategori::where('id', $id)->update([
                'petunjuk' => "/" . $folder . "/" . $file->getClientOriginalName()
            ]);
        }
        $pembayaran = Kategori::where('id', $id)->update([
            'nama' => $request->kategori,
            'kode' => $request->kode,
            'publisher' => $request->publisher,
            'tipe' => $request->tipe,
            'status' => $request->status,
            'server_id' => $request->serverOption == 'ya' ? 1 : 0,
        ]);

        return back()->with('success', 'Berhasil update kategori');
    }
}
