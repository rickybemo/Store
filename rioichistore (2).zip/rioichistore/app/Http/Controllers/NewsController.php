<?php

namespace App\Http\Controllers;

use App\Models\News;
use Illuminate\Http\Request;

class NewsController extends Controller
{
    public function create(Request $request, $type = null)
    {
        if($type == "all" && $request->search){
            $news = News::where('title', 'like', '%'.$request->search.'%')
                    ->orderBy('created_at', 'desc')
                    ->paginate(10)->withQueryString();
        }else if($type == "promo" && $request->search){
            $news  = News::where('title', 'like', '%'.$request->search.'%')
                    ->orderBy('created_at', 'desc')
                    ->where('type', 'promo')->paginate(10)->withQueryString();
        }else if($type == "news" && $request->search){
            $news = News::where('title', 'like', "%$request->search%")
                    ->orderBy('created_at', 'desc')
                    ->where('type', 'news')->paginate(10)->withQueryString();
        }else{
            $news = News::orderBy('created_at', 'desc')->paginate(10)->withQueryString();
        }

        return view('components.news', ['datas' => $news]);
    }

    public function show(News $news)
    {
        // $news = News::where('slug', $slug)->first();

        if(!$news) return abort(404);

        return view('components.readNews', ['news' => $news]);
    }
}
