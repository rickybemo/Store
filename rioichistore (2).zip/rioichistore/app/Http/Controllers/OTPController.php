<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Waysend;
use Illuminate\Http\Request;

class OTPController extends Controller
{
    public function index(Request $request, $id)
    {
        $data = array("username" => $id);
        return view('components.otp')->with($data);
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'kode_otp' => 'required|min:6|max:6',
        ], [
            'username.required' => 'Harap isi kolom username!',
            'kode_otp' => 'Harap isi kolom kode OTP',
            'kode_otp.min' => 'Panjang OTP minimal 6 huruf',
            'kode_otp.max' => 'Panjang OTP maximal 6 huruf',
        ]);

        $user = User::where('username', $request->username)->first();
        if($user->is_verified != 0) {
            return redirect(route('login'))->with('error', 'Akun kamu sudah di Aktivasi, silahkan Login');
        } else {
            if($request->kode_otp == $user->kode_otp) {
                $user->kode_otp    = NULL;
                $user->is_verified = 1;
                $user->save();
                
                return redirect(route('login'))->with('success', 'Berhasil melakukan pendaftaran');
            } else {
                return redirect()->back()->with('error', 'Kode OTP tidak valid');
            }
        }
    }
    
    public function request(Request $request, $id) {
        $user = User::where('username', $id)->first();
        if($user->is_verified != 0) {
            return redirect(route('login'))->with('error', 'Akun kamu sudah di Aktivasi, silahkan Login');
        } else {
            $makeOTP = $this->generateRandomString(6);
            $user->kode_otp = $makeOTP;
            $user->save();
            
            $pesan = "Halo ".$request->nama." \n\nKode OTP kamu adalah *$makeOTP*. Terima kasih telah melakukan pendaftaran di *".ENV('APP_NAME')."*";
            $this->msg($user->no_telepon, $pesan);

            return redirect(route('otp', $id))->with('msg', 'Halo, Masukkan kode otp yang telah kami kirimkan via Whatsapp.');
        }
    }
    
    public function generateRandomString($length) {
        $characters = '0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    
    public function msg($nomor, $msg)
    {

        $waysender = Waysend::find(1);
        $data = [
            'api_key' => $waysender->key,
            'sender'  => $waysender->number,
            'number'  => "$nomor",
            'message' => "$msg"
        ];

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $waysender->api_url.'/send-message',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
}
