<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kategori;
use App\Models\Layanan;
use App\Models\Pembayaran;
use App\Models\Voucher;
use App\Models\Pembelian;
use App\Models\User;
use App\Http\Controllers\DuniaGames;
use App\Http\Controllers\ApiBoController;
use Illuminate\Support\Str;
use App\Http\Controllers\TriPayController;
use App\Http\Controllers\digiFlazzController;
use App\Http\Controllers\iPaymuController;
use App\Http\Controllers\VipResellerController;
use App\Http\Controllers\JulyhyusController;
use App\Http\Controllers\ApiCheckController;
use App\Http\Controllers\SmileOneController;
use App\Http\Controllers\ApiGamesController;
use App\Models\Waysend;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class OrderController extends Controller
{
    public function create(Kategori $kategori)
    {
        $data = Kategori::where('kode', $kategori->kode)->select('nama', 'server_id', 'thumbnail', 'id', 'kode', 'petunjuk', 'kolom_jumlah', 'tipe')->first();
        if ($data == null) return back();

        if (Auth::check()) {
            if (Auth::user()->role == "Member") {
                $layanan = Layanan::where('kategori_id', $data->id)->where('status', 'available')->select('id', 'layanan', 'product_logo', 'harga')->orderBy('harga', 'asc')->get();
            } else if (Auth::user()->role == "Gold") {
                $layanan = Layanan::where('kategori_id', $data->id)->where('status', 'available')->select('id', 'layanan', 'product_logo', 'harga_reseller AS harga')->orderBy('harga', 'asc')->get();
            } else if (Auth::user()->role == "Platinum" || Auth::user()->role == "Admin") {
                $layanan = Layanan::where('kategori_id', $data->id)->where('status', 'available')->select('id', 'layanan', 'product_logo', 'harga_vip AS harga')->orderBy('harga', 'asc')->get();
            }
        } else {
            $layanan = Layanan::where('kategori_id', $data->id)->where('status', 'available')->select('id', 'layanan', 'product_logo', 'harga')->orderBy('harga', 'asc')->get();
        }

        return view('components.order', [
            'title' => $data->nama,
            'kategori' => $data,
            'nominal' => $layanan,
        ]);
    }

    public function price(Request $request)
    {
        if (Auth::check()) {
            if (Auth::user()->role == "Member") {
                $data = Layanan::where('id', $request->nominal)->select('harga AS harga')->first();
            } else if (Auth::user()->role == "Gold") {
                $data = Layanan::where('id', $request->nominal)->select('harga_reseller AS harga')->first();
            } else if (Auth::user()->role == "Platinum" || Auth::user()->role == "Admin") {
                $data = Layanan::where('id', $request->nominal)->select('harga_vip AS harga')->first();
            }
        } else {
            $data = Layanan::where('id', $request->nominal)->select('harga AS harga')->first();
        }

        if (isset($request->jumlah)) {
            $data->harga *= $request->jumlah;
        }

        if (isset($request->voucher)) {
            $voucher = Voucher::where('kode', $request->voucher)->first();

            if (!$voucher) {
                $data->harga = $data->harga;
            } else {
                if ($voucher->stock == 0) {
                    $data->harga = $data->harga;
                } else {
                    $potongan = $data->harga * ($voucher->promo / 100);
                    if ($potongan > $voucher->max_potongan) {
                        $potongan = $voucher->max_potongan;
                    }

                    $data->harga = $data->harga - $potongan;
                }
            }
        }

        if ($data->harga < 0) {
            $data->harga = 0;
        }

        return response()->json([
            'status' => true,
            'harga' => "Rp. " . number_format($data->harga, 0, '.', ',')
        ]);
    }

    public function confirm(Request $request)
    {
        $request->validate([
            'uid' => 'required',
            'service' => 'required|numeric',
            'payment_method' => 'required',
            'nomor' => 'required|numeric',
        ]);
            //$data = "secret=".ENV('CAPTCHA_SECRET')."&response=".$request->captcha;
            //$ch = curl_init("https://www.google.com/recaptcha/api/siteverify");
            //curl_setopt($ch, CURLOPT_POST, true);
            //curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            //curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            //$exec = json_decode(curl_exec($ch));

        $lolhuman = new DuniaGames();
        $smile = new SmileOneController();
        $apibo = new ApiBoController();
        $apicheck = new ApiCheckController();

        if (Auth::check()) {
            if (Auth::user()->role == "Member") {
                $dataLayanan = Layanan::where('id', $request->service)->select('harga', 'kategori_id')->first();
            } else if (Auth::user()->role == "Gold") {
                $dataLayanan = Layanan::where('id', $request->service)->select('harga_reseller AS harga', 'kategori_id')->first();
            } else if (Auth::user()->role == "Platinum" || Auth::user()->role == "Admin") {
                $dataLayanan = Layanan::where('id', $request->service)->select('harga_vip AS harga', 'kategori_id')->first();
            }
        } else {
            $dataLayanan = Layanan::where('id', $request->service)->select('harga AS harga', 'kategori_id')->first();
        }

        if (isset($request->jumlah)) {
            if ($request->jumlah < 0) return response()->json(['status' => false, 'data' => 'Jumlah tidak valid']);

            $dataLayanan->harga *= $request->jumlah;
        }

        if (isset($request->voucher)) {
            $voucher = Voucher::where('kode', $request->voucher)->first();

            if (!$voucher) {
                $dataLayanan->harga = $dataLayanan->harga;
            } else {
                if ($voucher->stock == 0) {
                    $dataLayanan->harga = $dataLayanan->harga;
                } else {
                    $potongan = $dataLayanan->harga * ($voucher->promo / 100);
                    if ($potongan > $voucher->max_potongan) {
                        $potongan = $voucher->max_potongan;
                    }

                    $dataLayanan->harga = $dataLayanan->harga - $potongan;
                }
            }
        }

        if ($dataLayanan->harga < 0) {
            return response()->json(['status' => false, 'data' => 'Harga tidak valid']);
        }

        $dataKategori = Kategori::where('id', $dataLayanan->kategori_id)->select('kode', 'tipe')->first();

        if ($dataKategori->tipe != "joki") {
            $daftarGameValidasi = ['point-blank', 'mobile-legends', 'mobile-legend', 'free-fire', 'call-of-duty', 'aov', 'sausageman', 'apex-legends', 'valorant', 'ragnarok-m', 'dragon-raja', 'marvel-super-war', 'lords-mobile', 'genshin-impact', 'tom-jerry-chase', 'pubg'];

            if (in_array($dataKategori->kode, $daftarGameValidasi)) {
                if ($dataKategori->kode == 'point-blank') {
                    $data = $apicheck->check($request->uid, null, 'Point Blank');
                } else if ($dataKategori->kode == 'mobile-legends') {
                    $data = $smile->checkid($request->uid, $request->zone);
                } else if ($dataKategori->kode == 'mobile-legend') {
                    $data = $smile->checkid($request->uid, $request->zone);
                } else if ($dataKategori->kode == "free-fire") {
                    $data = $apicheck->check($request->uid, null, 'Free Fire');
                } else if ($dataKategori->kode == "aov") {
                    $data = $apicheck->check($request->uid, null, 'AOV');
                } else if ($dataKategori->kode == 'apex-legends') {
                    $data = $apicheck->check($request->uid, null, 'Apex Legends');
                } else if ($dataKategori->kode == "valorant") {
                    $data = $apicheck->check($request->uid, null, 'Valorant');
                } else if ($dataKategori->kode == "lords-mobile") {
                    $data = $apicheck->check($request->uid, null, 'Lords Mobile');
                } else if ($dataKategori->kode == "tom-jerry-chase") {
                    $data = $apicheck->check($request->uid, null, 'Tom Jerry Chase');
                } else if ($dataKategori->kode == "dragon-raja") {
                    $data = $apicheck->check($request->uid, null, 'Dragon Raja');
                } else if ($dataKategori->kode == "ragnarok-m") {
                    $data = $apicheck->check($request->uid, $request->zone, 'Ragnarok M');
                } else if ($dataKategori->kode == "marvel-super-war") {
                    $data = $apicheck->check($request->uid, null, 'Marvel Super War');
                } else if ($dataKategori->kode == "genshin-impact") {
                    $data = $apicheck->check($request->uid, $request->zone, 'Genshin Impact');
                } elseif ($dataKategori->kode == "sausageman") {
                    $data = $lolhuman->sausageman($request->uid);
                } elseif ($dataKategori->kode == "pubg") {
                    $data = $lolhuman->pubg($request->uid);
                } elseif ($dataKategori->kode == "call-of-duty") {
                    $data = $lolhuman->codm($request->uid);
                }
                if (!$data) {
                    return response()->json([
                        'status' => false,
                        'message' => 'Terjadi kesalahan, coba lagi nanti'
                    ]);
                }
                if ($data['status']['code'] == 1) {
                    return response()->json([
                        'status' => false,
                        'message' => isset($data['data']['msg']) ? $data['data']['msg'] : 'Username tidak ditemukan atau coba lagi nanti'
                    ]);
                }
                $username = $data['data']['userNameGame'];

                $sendData = "Nickname : <span id='nick'>$username</span><br>
                                ID : $request->uid $request->zone<br>
                                Harga : Rp. " . number_format($dataLayanan->harga, 0, '.', ',') .
                    "<br>Metode Pembayaran : " . strtoupper($request->payment_method) .
                    "<br><br>Catatan : Harga diatas belum termasuk biaya admin";

                return response()->json([
                    'status' => true,
                    'data' => $sendData
                ]);
            } else {
                $sendData = "ID : <span id='nick'>$request->uid</span><br>
                                Harga : Rp. " . number_format($dataLayanan->harga, 0, '.', ',') .
                    "<br>Metode Pembayaran : " . strtoupper($request->payment_method) .
                    "<br><br>Catatan : Harga diatas belum termasuk biaya admin";

                return response()->json([
                    'status' => true,
                    'data' => $sendData
                ]);
            }
        } else {
            $sendData = "Email : " . $request->uid . "<br>" .
                "Password : " . $request->zone . "<br>" .
                "Metode Pembayaran : " . strtoupper($request->payment_method) . "<br>" .
                "Harga : Rp. " . number_format($dataLayanan->harga, 0, '.', ',') . "<br>" .
                "<br>Catatan : Harga diatas belum termasuk biaya admin";

            return response()->json([
                'status' => true,
                'data' => $sendData
            ]);
        }
    }

     public function store(Request $request)
    {
        $request->validate([
            'uid' => 'required',
            // 'nickname' => 'required',
            'service' => 'required|numeric',
            'payment_method' => 'required',
            'nomor' => 'required|numeric',
        ]);
        
        $requestEmail = "info@".parse_url(ENV("APP_URL"), PHP_URL_HOST);


        if (Auth::check()) {
            if (Auth::user()->role == "Member") {
                $dataLayanan = Layanan::where('id', $request->service)->select('layanan', 'harga AS harga', 'kategori_id', 'provider_id', 'provider')->first();
            } else if (Auth::user()->role == "Gold") {
                $dataLayanan = Layanan::where('id', $request->service)->select('layanan', 'harga_reseller AS harga', 'kategori_id', 'provider_id', 'provider')->first();
            } else if (Auth::user()->role == "Platinum" || Auth::user()->role == "Admin") {
                $dataLayanan = Layanan::where('id', $request->service)->select('layanan', 'harga_vip AS harga', 'kategori_id', 'provider_id', 'provider')->first();
            }
        } else {
            $dataLayanan = Layanan::where('id', $request->service)->select('layanan', 'harga AS harga', 'kategori_id', 'provider_id', 'provider')->first();
        }

        if (isset($request->jumlah)) {
            if ($request->jumlah < 0) return response()->json(['status' => false, 'data' => 'Jumlah tidak valid']);
            $dataLayanan->harga *= $request->jumlah;
        }

        if (isset($request->voucher)) {
            $voucher = Voucher::where('kode', $request->voucher)->first();

            if (!$voucher) {
                $dataLayanan->harga = $dataLayanan->harga;
            } else {
                if ($voucher->stock == 0) {
                    $dataLayanan->harga = $dataLayanan->harga;
                } else {
                    $potongan = $dataLayanan->harga * ($voucher->promo / 100);
                    if ($potongan > $voucher->max_potongan) {
                        $potongan = $voucher->max_potongan;
                    }

                    $dataLayanan->harga = $dataLayanan->harga - $potongan;
                    $voucher->decrement('stock');
                }
            }
        }

        if ($dataLayanan->harga < 0) return response()->json(['status' => false, 'data' => 'Harga tidak valid']);
    
        $kategori = Kategori::where('id', $dataLayanan->kategori_id)->select('kode', 'tipe')->first();

        $order_id = 'RS' . rand(0000000,9999999);
        // $tripay = new TriPayController();  
        $ipaymu = new iPaymuController();

        $rand = rand(1000, 1000);
        $no_pembayaran = '';
        $amount = '';
        $reference = '';

        if ($request->payment_method == "ovo" || $request->payment_method == "gopay" || $request->payment_method == "bcatf") {

            $amount = $dataLayanan->harga + $rand;
            $reference = '';
            if ($request->payment_method == "ovo") {
                $no_pembayaran = ENV("OVO_ADMIN");
            } else if ($request->payment_method == "bcatf") {
                $no_pembayaran = ENV("NOMOR_REK");
            } else {
                $no_pembayaran = ENV("GOPAY_ADMIN");
            }
        } else if ($request->payment_method == "qris") {

            $ipayres = $ipaymu->requestPayment((($dataLayanan->harga + 1000) * 0) + $dataLayanan->harga + 1000, $order_id, $request->nomor, 'qris', $requestEmail, 'qris');

            if ($ipayres['Status'] != 200) return response()->json(['status' => false, 'data' => 'Metode pembayaran ini sedang tidak dapat digunakan']);

            $no_pembayaran = $ipayres['Data']['QrTemplate'];
            $reference = $ipayres['Data']['TransactionId'];
            $amount = $ipayres['Data']['Total'];
        } else if ($request->payment_method == "permata" || $request->payment_method == "bri" || $request->payment_method == "bni" || $request->payment_method == "cimb" || $request->payment_method == "bsi" || $request->payment_method == "bmi") {

            $ipayres = $ipaymu->requestPayment((($dataLayanan->harga + 4000) * 0) + $dataLayanan->harga + 4000, $order_id, $request->nomor, 'va', $requestEmail, $request->payment_method);

            if ($ipayres['Status'] != 200) return response()->json(['status' => false, 'data' => 'Metode pembayaran ini sedang tidak dapat digunakan']);

            $no_pembayaran = $ipayres['Data']['PaymentNo'];
            $reference = $ipayres['Data']['TransactionId'];
            $amount = $ipayres['Data']['Total'];
        } else if ($request->payment_method == "bca" || $request->payment_method == "mandiri" || $request->payment_method == "bag") {
            
            $ipayres = $ipaymu->requestPayment((($dataLayanan->harga + 4000) * 0) + $dataLayanan->harga + 4000, $order_id, $request->nomor, 'va', $requestEmail, $request->payment_method);

            if ($ipayres['Status'] != 200) return response()->json(['status' => false, 'data' => 'Metode pembayaran ini sedang tidak dapat digunakan']);

            $no_pembayaran = $ipayres['Data']['PaymentNo'];
            $reference = $ipayres['Data']['TransactionId'];
            $amount = $ipayres['Data']['Total'];
        } else if ($request->payment_method == "alfamart") {

            $ipayres = $ipaymu->requestPayment((($dataLayanan->harga + 4000) * 0) + $dataLayanan->harga + 4000, $order_id, $request->nomor, 'cstore', $requestEmail, $request->payment_method);

            if ($ipayres['Status'] != 200) return response()->json(['status' => false, 'data' => 'Metode pembayaran ini sedang tidak dapat digunakan']);


            $no_pembayaran = $ipayres['Data']['PaymentNo'];
            $reference = $ipayres['Data']['TransactionId'];
            $amount = $ipayres['Data']['Total'];
        } else if ($request->payment_method == "indomaret") {

            $ipayres = $ipaymu->requestPayment((($dataLayanan->harga + 4000) * 0) + $dataLayanan->harga + 4000, $order_id, $request->nomor, 'cstore', $requestEmail, $request->payment_method);

            if ($ipayres['Status'] != 200) return response()->json(['status' => false, 'data' => 'Metode pembayaran ini sedang tidak dapat digunakan']);


            $no_pembayaran = $ipayres['Data']['PaymentNo'];
            $reference = $ipayres['Data']['TransactionId'];
            $amount = $ipayres['Data']['Total'];
        } else if ($request->payment_method == "Saldo") {
            $amount = $dataLayanan->harga;
        } else {

            return response()->json([
                'status'     => false,
                'data'    => "Tipe pembayaran tidak sah"
            ]);
        }

        if ($request->payment_method == "ovo" || $request->payment_method == "gopay" || $request->payment_method == "bca") {
            $pesan = "*Detail Pesanan*

*• No Invoice :* *$order_id*
*• ID / Server :* $request->uid ($request->zone)
*• Nickname :* $request->nickname
*• Produk :* $dataLayanan->layanan
*• Metode Pembayaran:* ".strtoupper($request->payment_method)."
*• Nomor Pembayaran:* $no_pembayaran
*• Harga :* Rp. " . number_format($amount, 0, '.', ',') . "
*• Status :* Belum Dibayar
*• Invoice:* " . env("APP_URL") . "/pembelian/invoice/$order_id

Lakukan pembayaran sebelum 1x24 Jam


*Pesan Otomatis*
";
        } else if ($request->payment_method == "Saldo") {
            $pesan = "*Pesanan Saldo (Sukses)*

*• No Invoice :* *$order_id*
*• ID / Server :* $request->uid ($request->zone)
*• Nickname :* $request->nickname
*• Produk :* $dataLayanan->layanan
*• Metode Pembayaran:* ".strtoupper($request->payment_method)."
*• Harga :* Rp. " . number_format($amount, 0, '.', ',') . "
*• Status :* *Berhasil*
*• Invoice:* " . env("APP_URL") . "/pembelian/invoice/$order_id

*Pesan Otomatis*
";
        } else {
            $pesan = "*Detail Pesanan* [Belum Dibayar]

*• No Invoice :* *$order_id* 
*• ID / Server :* $request->uid ($request->zone)
*• Nickname :* $request->nickname
*• Produk :* $dataLayanan->layanan
*• Metode Pembayaran:* ".strtoupper($request->payment_method)."
*• Nomor Pembayaran:* $no_pembayaran
*• Harga :* Rp. " . number_format($amount, 0, '.', ',') . "
*• Status :* Belum Dibayar
*• Invoice:* " . env("APP_URL") . "/pembelian/invoice/$order_id


Lakukan pembayaran sebelum 1x24 Jam

*Pesan Otomatis*
";
        }

        if ($request->payment_method != "Saldo") {
            $requestPesan = $this->msg($request->nomor, $pesan);

            $pembelian = new Pembelian();
            $pembelian->order_id = $order_id;
            $pembelian->user_id = $request->uid;
            $pembelian->zone = $request->zone;
            $pembelian->nickname = $request->nickname;
            $pembelian->layanan = $dataLayanan->layanan;
            $pembelian->harga = $amount;
            $pembelian->profit = $amount * ENV("MARGIN_PROFIT");
            $pembelian->status = 'Menunggu';
            if ($kategori->tipe == "joki") {
                $tipe = "joki";
            } else {
                $tipe = "game";
            }
            $pembelian->tipe_transaksi = $tipe;
            if ($tipe == "joki") {
                $pembelian->catatan = "Jumlah : " . $request->jumlah . "\n" .
                    "Req Hero : " . $request->reqHero . "\n" .
                    "Login Via :" . $request->login . "\n";
            }
            $pembelian->save();

            $pembayaran = new Pembayaran();
            $pembayaran->order_id = $order_id;
            $pembayaran->harga = $amount;
            $pembayaran->no_pembayaran = $no_pembayaran;
            $pembayaran->no_pembeli = $request->nomor;
            $pembayaran->status = 'Belum Lunas';
            $pembayaran->metode = $request->payment_method;
            $pembayaran->reference = $reference;
            $pembayaran->save();
        } else if ($request->payment_method == "Saldo") {
            $requestPesan = $this->msg($request->nomor, $pesan);
            $latestOrder = Pembelian::where('user_id', $request->uid)->where('created_at', '<', now())->whereIn('status', ['Pending', "Success"])->latest()->first();
            if ($latestOrder) {
                $latestPayment = Pembayaran::where('order_id', $latestOrder->order_id)->where('metode', 'Saldo')->latest()->first();
                if ($latestPayment) {
                    $latestPaymentDate = new \DateTime($latestPayment->created_at);
                    $diffrentTime = $latestPaymentDate->diff(new \DateTime(now()));
                    $totalminutes = $diffrentTime->days * 24 * 60;
                    $totalminutes += $diffrentTime->h * 60;
                    $totalminutes += $diffrentTime->i;
                    if ($totalminutes <= 2) return response()->json(['status' => false, 'data' => 'Anda memiliki orderan yang sama. Harap mencoba kembali 1-2 menit kedepan']);
                }
            }

            $user = User::where('username', Auth::user()->username)->first();

            if ($dataLayanan->harga > $user->balance) return response()->json(['status' => false, 'data' => 'Saldo anda tidak cukup']);

            $userBalance = $user->balance;

            $user->update([
                'balance' => $userBalance - $dataLayanan->harga
            ]);

            if ($kategori->kode == "mobile-legend") {
                $smile = new SmileOneController;
                $order = $smile->order($request->uid, $request->zone, $dataLayanan->provider_id);
                if ($order['status']) {
                    $order['status'] = true;
                    $provider_order_id = $order['transactionId'];
                }
            } else {
                if ($dataLayanan->provider == "digiflazz") {
                    $digi = new digiFlazzController;
                    $provider_order_id = rand(1, 100000);
                    $order = $digi->order($request->uid, $request->zone, $dataLayanan->provider_id, $provider_order_id);

                    if ($order['data']['status'] == "Pending" || $order['data']['status'] == "Sukses") {
                        $order['status'] = true;
                    } else {
                        $order['status'] = false;
                    }
                } else if ($dataLayanan->provider == "vip") {
                    $vip = new VipResellerController;
                    $order = $vip->order($request->uid, $request->zone, $dataLayanan->provider_id);

                    if ($order['result']) {
                        $order['status'] = true;
                        $provider_order_id = $order['data']['trxid'];
                    } else {
                        $order['status'] = false;
                    }
                } else if ($dataLayanan->provider == "apigames") {
                    $provider_order_id = rand(1, 10000);
                    $apigames = new ApiGamesController;
                    $order = $apigames->order($request->uid, $request->zone, $dataLayanan->provider_id, $provider_order_id);

                    if ($order['data']['status'] == "Sukses") {
                        $order['transactionId'] = $provider_order_id;
                        $order['status'] = true;
                    } else {
                        $order['status'] = false;
                    }
                } else if ($dataLayanan->provider == "july") {
                    $july = new JulyhyusController;
                    $order = $july->order($request->uid, $request->zone, $dataLayanan->provider_id);
                    // dd($order);
                    if ($order['result']) {
                        $order['status'] = true;
                        $provider_order_id = $order['data']['trxid'];
                    } else {
                        $order['status'] = false;
                    }
                } else if ($dataLayanan->provider == "manual") {
                    $order['status'] = true;
                    $provider_order_id = "MANUAL";
                }
            }

            if ($order['status']) {

                $pesan = "*Pesanan Berhasil*
                
*• No Invoice :* *$order_id*
*• ID / Server :* $request->uid ($request->zone)
*• Nickname :* $request->nickname
*• Produk :* $dataLayanan->layanan
*• Metode Pembayaran:* ".strtoupper($request->payment_method)."
*• Nomor Pembayaran:* $no_pembayaran
*• Harga :* Rp. " . number_format($amount, 0, '.', ',') . "
*• Status :* Berhasil
*• Invoice:* " . env("APP_URL") . "/pembelian/invoice/$order_id

*Pesan Otomatis*
";


                $requestPesan = $this->msg($request->nomor, $pesan);
                $requestPesanAdmin = $this->msg(ENV("NOMOR_ADMIN"), $pesan);
                $requestPesanAdmin = $this->msg(ENV("CUSTWA"), $pesan);


                $pembelian = new Pembelian();
                $pembelian->username = Auth::user()->username;
                $pembelian->order_id = $order_id;
                $pembelian->user_id = $request->uid;
                $pembelian->zone = $request->zone;
                $pembelian->nickname = $request->nickname;
                $pembelian->layanan = $dataLayanan->layanan;
                $pembelian->harga = $dataLayanan->harga;
                $pembelian->profit = $dataLayanan->harga * ENV("MARGIN_PROFIT");
                $pembelian->status = 'Pending';
                $pembelian->provider_order_id = $provider_order_id ? $provider_order_id : "";
                $pembelian->log = json_encode($order);
                if ($kategori->tipe == "joki") {
                    $tipe = "joki";
                } else {
                    $tipe = "game";
                }
                $pembelian->tipe_transaksi = $tipe;
                if ($tipe == "joki") {
                    $pembelian->catatan = "Jumlah : " . $request->jumlah . "\n" .
                        "Req Hero : " . $request->reqHero . "\n" .
                        "Login Via :" . $request->login . "\n";
                }
                $pembelian->save();

                $pembayaran = new Pembayaran();
                $pembayaran->order_id = $order_id;
                $pembayaran->harga = $dataLayanan->harga;
                $pembayaran->no_pembayaran = "Saldo";
                $pembayaran->no_pembeli = $request->nomor;
                $pembayaran->status = 'Lunas';
                $pembayaran->metode = $request->payment_method;
                $pembayaran->reference = $reference;
                $pembayaran->save();
            } else {
                $user->update([
                    'balance' => $userBalance
                ]);
                return response()->json([
                    'status' => false,
                    'data' => 'Server Error',
                    'order' => $order
                ]);
            }
        }
        
        return response()->json([
            'status' => true,
            'order_id' => $order_id
        ]);
    }

    public function msg($nomor, $msg)
    {

        $waysender = Waysend::find(1);
        $data = [
            'api_key' => $waysender->key,
            'sender'  => $waysender->number,
            'number'  => "$nomor",
            'message' => "$msg"
        ];

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://wabot.riostore.my.id/send-message',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
}
