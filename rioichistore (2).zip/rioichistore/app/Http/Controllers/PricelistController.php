<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use Illuminate\Http\Request;
use App\Models\Layanan;

class PricelistController extends Controller
{
    public function create(Request $request)
    {
        
        if($request->q){
            $datas = Layanan::join('kategoris', 'layanans.kategori_id', 'kategoris.id')
                    ->where('kategoris.nama', 'LIKE', "%".$request->q."%")
                    ->where('kategoris.status', 'active')->orderBy('created_at', 'desc')
                    ->select('layanans.*', 'kategoris.nama AS nama_kategori')->paginate(10)->withQueryString();;
        }else{
            $datas = Layanan::join('kategoris', 'layanans.kategori_id', 'kategoris.id')->where('kategoris.status', 'active')->orderBy('created_at', 'desc')
                    ->select('layanans.*', 'kategoris.nama AS nama_kategori')->paginate(10)->withQueryString();;
        }

        $kategori = Kategori::get();

        return view('components.pricelist', ['datas' => $datas, 'kategoris' => $kategori]);
    }
    
    public function priceJson(Request $request) {
        if($request->filter_game) {
            $datas = Layanan::join('kategoris', 'layanans.kategori_id', 'kategoris.id')
                    ->where('kategoris.id', $request->filter_game)
                    ->where('kategoris.status', 'active')->orderBy('created_at', 'desc')
                    ->select('layanans.*', 'kategoris.nama AS nama_kategori')->paginate(10)->withQueryString();
        } else {
            $datas = Layanan::join('kategoris', 'layanans.kategori_id', 'kategoris.id')->where('kategoris.status', 'active')->orderBy('created_at', 'desc')
                    ->select('layanans.*', 'kategoris.nama AS nama_kategori')->paginate(20)->withQueryString();
        }
        
        echo json_encode($datas);
    }
}
