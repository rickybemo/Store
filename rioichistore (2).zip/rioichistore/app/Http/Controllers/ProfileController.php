<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pembelian;
use App\Models\Pembayaran;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class ProfileController extends Controller
{
    public function create(Request $request)
    {
        if ($request->q) {
            $pembelian = Pembelian::where('layanan', 'LIKE', '%' . $request->q . '%')->where('username', Auth::user()->username)->paginate(10)->withQueryString();
        } else {
            $pembelian = Pembelian::where('username', Auth::user()->username)->paginate(10)->withQueryString();
        }

        return view('components.profile', ['pembelian' => $pembelian]);
    }

    public function upgrade()
    {
        // dd(Auth::user()->role != "Member" && Auth::user()->role != "Gold");
        if (Auth::user()->role != "Member" && Auth::user()->role != "Gold") {
            return redirect(route('profile'));
        }
        return view('components.upgrade');
    }

    public function upgradeRole(Request $request)
    {
        $user = User::where('username', Auth::user()->username)->first();
        if (Auth::user()->role == "Member") {
            if ($request->role == "Gold") {
                $harga = 99000;
            } else if ($request->role == "Platinum") {
                $harga = 199000;
            } else {
                return back()->with('error', 'Role tidak valid');
            }
        } else if (Auth::user()->role == "Gold") {
            if ($request->role == "Platinum") {
                $harga = 100000;
            } else {
                return back()->with('error', 'Role tidak valid');
            }
        } else {
            return redirect(route('profile'));
        }

        if ($user->balance < $harga) {
            return back()->with('error', 'Saldo anda kurang untuk melakukan upgrade');
        }

        $order_id = Str::random('6');
        $pembelian = new Pembelian();
        $pembelian->username = Auth::user()->username;
        $pembelian->order_id = $order_id;
        $pembelian->user_id = Auth::user()->username;
        $pembelian->nickname = Auth::user()->username;
        $pembelian->layanan = "Upgrade Role " . strtoupper($user->role) . " Ke " . $request->role;
        $pembelian->profit = $harga;
        $pembelian->harga = $harga;
        $pembelian->status = 'Success';
        $pembelian->tipe_transaksi = 'upgrade';
        $pembelian->save();

        $user->update([
            'balance' => $user->balance - $harga,
            'role' => $request->role
        ]);

        $pembayaran = new Pembayaran();
        $pembayaran->order_id = $order_id;
        $pembayaran->harga = $harga;
        $pembayaran->no_pembayaran = "Saldo";
        $pembayaran->no_pembeli = "1234567890";
        $pembayaran->status = 'Lunas';
        $pembayaran->metode = "Saldo";
        $pembayaran->save();

        return back()->with('success', 'Berhasil mengupgrade role');
    }
}
