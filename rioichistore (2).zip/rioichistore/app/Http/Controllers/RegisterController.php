<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Waysend;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function create()
    {
        return view('components.register');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'no_telepon' => 'required|min:9|max:16|unique:users,no_telepon',
            'username' => 'required|min:3|unique:users,username|max:255',
            'password' => 'required|min:6|max:255',
        ], [
            'nama.required' => 'Harap isi kolom nama!',
            'no_telepon.required' => 'Harap isi kolom ini!',
            'no_telepon.unique' => 'Nomor telepon telah digunakan',
            'no_telepon.min' => 'Panjang no telepon minimal 9 digit!',
            'no_telepon.max' => 'Panjang no telepin maximal 16 digit!',
            'username.required' => 'Harap isi kolom username!',
            'username.min' => 'Panjang username minimal 3 huruf',
            'username.unique' => 'Username telah digunakan',
            'username.max' => 'Panjang username maximal 255 huruf',
            'password' => 'Harap isi kolom password',
            'password.min' => 'Panjang password minimal 6 huruf',
            'password.max' => 'Panjang password maximal 255 huruf',
        ]);
        
        if(substr($request->no_telepon, 0, 2) == "62") {
            $setNo = str_replace(substr($request->no_telepon, 0, 2), "62", "0");
            $notel = $setNo."".substr($request->no_telepon, 2);
            
            $users = User::where("no_telepon", $notel)->count();
            if($users > 0) {
                return redirect()->back()->with('error', 'Nomor telepon telah digunakan');
                die();
            } 
        } else {
            $notel = $request->no_telepon;
        }
        
        $user = new User();
        
        $makeOTP = $this->generateRandomString(6);
        
        $user->name        = $request->nama;
        $user->username    = $request->username;
        $user->no_telepon  = $notel;
        $user->password    = Hash::make($request->password);
        $user->balance     = 0;
        $user->role        = 'Member';
        $user->kode_otp    = $makeOTP;
        $user->is_verified = 0;
        $user->save();
        
        $pesan = "Halo ".$request->nama." \n\nKode OTP kamu adalah *$makeOTP*. Terima kasih telah melakukan pendaftaran di *".ENV('APP_NAME')."*";
        $this->msg($notel, $pesan);

        return redirect(route('otp', $request->username))->with('msg', 'Halo, Masukkan kode otp yang telah kami kirimkan via Whatsapp.');
    }
    
    public function generateRandomString($length) {
        $characters = '0123456789';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
    
    public function msg($nomor, $msg)
    {

        $waysender = Waysend::find(1);
        $data = [
            'api_key' => $waysender->key,
            'sender'  => $waysender->number,
            'number'  => "$nomor",
            'message' => "$msg"
        ];

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $waysender->api_url.'/send-message',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
}
