<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pembelian;
use Illuminate\Support\Facades\Auth;

class RiwayatPembelian extends Controller
{
    public function create()
    {
        return view('components.riwayat', ['data' => Pembelian::orderBy('created_at', 'desc')->paginate(10)]);
    }

    public function show($id)
    {
        $data = Pembelian::where('order_id', $id)->first();
        $zone = $data->zone != null ? "-" . $data->zone : "";

        if ($data->status == "Pending" || $data->status == "Menunggu Pembayaran" || $data->status == "Waiting") {
            $label_pesanan = 'warning';
        } else if ($data->status == "Processing") {
            $label_pesanan = 'info';
        } else if ($data->status == "Success") {
            $label_pesanan = 'success';
        } else {
            $label_pesanan = 'danger';
        }

        $send = '
    <table class="table align-middle table-nowrap mb-0">
    <tbody>
            <tr>
                <th>Produk</th>
                <td>' . $data->layanan . '</td>
            </tr>
            <tr>
                <th>Target/UserId</th>
                <td>'.$data->user_id.'</td>
            </tr>
            <tr>
                <th>Harga</th>
                <td>Rp. ' . number_format($data->harga, 0, ',', '.') . '</td>
            </tr>
            <tr>
                <th>Tanggal</th>
                <td>'.date('d-m-Y H:i:s', strtotime($data->created_at)).'</td>
            </tr>
            <tr>
                <th>Status</th>
                <td><span class="badge bg-' . $label_pesanan . '">' . $data->status . '</span></td>
            </tr>
            <tr>
                <th>SN</th>
                <td>' . $data->sn . '</td>
            </tr>
    </tbody>
    </table>';

        return $send;
    }
        
}
