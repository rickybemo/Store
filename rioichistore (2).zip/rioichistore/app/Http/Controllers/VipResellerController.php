<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use App\Models\Layanan;
use App\Models\Vipreseller;
use Illuminate\Http\Request;

class VipResellerController extends Controller
{
    public function index()
    {
        $vipreseller = Vipreseller::find(1);
        return view('components.vipreseller', compact('vipreseller'));
    }
    public function change()
    {
        $vipreseller = Vipreseller::find(1);
        if ($vipreseller) {
            $vipreseller->api_id = request('api_id');
            $vipreseller->api_key = request('api_key');
            $vipreseller->save();
            return redirect()->back()->with('success', 'Berhasil mengubah data');
        } else {
            return redirect()->back()->with('error', 'Gagal mengubah data');
        }
    }
    public function order($uid = null, $zone = null, $service = null)
    {
        $vipseller = Vipreseller::find(1);
        $sign = md5($vipseller->api_id . $vipseller->api_key);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://vip-reseller.co.id/api/game-feature');
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "key=" . $vipseller->api_key . "&sign=$sign&type=order&service=$service&data_no=$uid&data_zone=$zone");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $res = json_decode(curl_exec($ch), true);
        return $res;
    }

    public function status($poid = null)
    {
        $vipseller = Vipreseller::find(1);
        $sign = md5($vipseller->api_id . $vipseller->api_key);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://vip-reseller.co.id/api/game-feature');
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "key=" . $vipseller->api_key . "&sign=$sign&type=status&trxid=$poid");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $res = json_decode(curl_exec($ch), true);
        return $res;
    }

    public function username($uid = null, $zone = null)
    {
        $vipseller = Vipreseller::find(1);
        $sign = md5($vipseller->api_id . $vipseller->api_key);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://vip-reseller.co.id/api/game-feature');
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "key=" . $vipseller->api_key . "&sign=$sign&type=$get_nickname&code=$code&service=$service&data_no=$uid&data_zone=$zone");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $res = json_decode(curl_exec($ch), true);
        return $res;
    }
    public function Layanan()
    {
        $vipseller = Vipreseller::find(1);
        $sign = md5($vipseller->api_id . $vipseller->api_key);
        $data = [
            'key' => $vipseller->api_key,
            'sign' => $sign,
            'type' => 'services',
        ];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://vip-reseller.co.id/api/game-feature');
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $res = json_decode(curl_exec($ch));
        $res = $res->data ?? null;
        // trunscate layanan
        if (!$res) {
            // return 'GAgal';
        }
        foreach ($res as $row) {
            $untung = 200;
            $kategori = Kategori::where('nama', $row->game)->first();
            if (!$kategori) {
                Kategori::create([
                    'nama' => $row->game,
                    'kode' => str_replace(' ', '-', $row->game),
                    'server_id' => 0,
                    'publisher' => 0,
                    'kolom_jumlah' => 0,
                    'status' => 'active',
                    'thumbnail' => 0,
                    'tipe' => 'game',
                    'petunjuk' => '0',
                ]);
            }
            $search = Layanan::where('provider_id', $row->code)->first();
            if ($search) {
                if ($search->harga < $untung) {
                    $search->layanan = $row->name;
                    $search->harga = $row->price->basic + ($row->price->basic * 7.1/100);
                    $search->harga_reseller = $row->price->basic + ($row->price->basic * 6.5/100);
                    $search->harga_vip = $row->price->basic + ($row->price->basic * 5.25/100);
                    $search->status = $row->status;
                    $search->save();
                }
            } else {
                $kategori = Kategori::where('nama', $row->game)->first();
                Layanan::create([
                    'kategori_id' => $kategori->id,
                    'layanan' => $row->name,
                    'provider_id' => $row->code,
                    'harga' => $row->price->basic + $untung,
                    'harga_reseller' => $row->price->premium + $untung,
                    'harga_vip' => $row->price->special + $untung,
                    'profit' => 0,
                    'catatan' => '0',
                    'status' => $row->status,
                    'provider' => 'vip',
                    'product_logo' => 0,
                ]);
            }
        }
    }
}
