<?php
require '../mainconfig.php';
    $CEK = $db->query("SELECT * FROM provider WHERE code='DF'");
    $DFs = $CEK->fetch_assoc();
    $hmem = $db->query("SELECT * FROM options WHERE opt_name='df_harga_member'");
    $hmems = $hmem->fetch_assoc();
    $hres = $db->query("SELECT * FROM options WHERE opt_name='df_harga_reseller'");
    $hress = $hres->fetch_assoc();
    $hpre = $db->query("SELECT * FROM options WHERE opt_name='df_harga_premium'");
    $hprem = $hpre->fetch_assoc();
    $h2h = $db->query("SELECT * FROM options WHERE opt_name='df_harga_h2hspecial'");
    $h2hh = $h2h->fetch_assoc();
    $df_user = $DFs['api_id'];
    $df_key = $DFs['api_key'];
    $sign = md5($df_user.$df_key."pricelist");
    $data = json_encode([
        "cmd" => 'prepaid',
        "username" => $df_user,
        "sign" => $sign
    ]);
    $header = array(
        'Content-Type: application/json',
    );
    $results = $curl->connectPost($DFs['link'].'price-list',$data);
    
    if (isset($results['data'])) {
        foreach($results['data'] as $loop) {
            
            $product = $loop['product_name'];
            $tipe = $loop['category'];
            $category = $loop['brand'];
            $type = $loop['type'];
            $buyer_sku_code = $loop['buyer_sku_code'];
            $desc = $loop['desc'];
            $status = $loop['seller_product_status'];
            
            $pmember = $loop['price'] * $hmems['opt_value'] / 100;
            $preseller = $loop['price'] * $hress['opt_value'] / 100;
            $ppremium = $loop['price'] * $hprem['opt_value'] / 100;
            $ph2hspecial = $loop['price'] * $h2hh['opt_value'] / 100;
            $price_member = $loop['price'] + $pmember;
            $price_reseller = $loop['price'] + $preseller;
            $price_premium = $loop['price'] + $ppremium;
            $price_h2hspecial = $loop['price'] + $ph2hspecial;
            $no = 1;
            $statuss = $status == true ? 'Normal' : 'Gangguan';
            
            if ($tipe == 'Data') {
                $tipee = 'DATA';
            } else if ($tipe == 'Pulsa') {
                $tipee = 'PULSA';
            } else if ($tipe == 'E-Money') {
                $tipee = 'EMONEY';
            } else if ($tipe == 'Games') {
                $tipee = 'VGAME';
            } else if ($tipe == 'PLN') {
                $tipee = 'PLN';
            } else if ($tipe == 'Voucher') {
                $tipee = 'VGAME';
            } else if ($tipe == 'Paket SMS & Telpon') {
                $tipee = 'SMSDANTELPON';
            } else {
                $tipee = 'VGAME';
            }
            $check_dataa = $db->query("SELECT * FROM layanan_pulsa WHERE operator='$category' AND service_id='$buyer_sku_code' AND tipe='$tipee' AND provider='DF'");
            if ($check_dataa->num_rows == 0) {
                $db->query("INSERT INTO `layanan_pulsa` (`id`, `service_id`, `provider_id`, `operator`, `layanan`, `img`,`min`,`max`, `harga`, `harga_reseller`, `harga_premium`, `harga_h2h`, `profit`, `status`, `provider`, `tipe`, `note`) VALUES ('', '$buyer_sku_code', '$buyer_sku_code', '$category', '$product', 'null','null','null','$price_member', '$price_reseller', '$price_premium', '$price_h2hspecial', '0', '$statuss', 'DF', '$tipee', '$desc')");
                $db->query("DELETE FROM layanan_pulsa WHERE status='Gangguan'");
                header('location:/admin/setting/provider');
            }else{
                $db->query("UPDATE layanan_pulsa SET status='$statuss', harga='$price_member', harga_reseller='$price_reseller', harga_premium='$price_premium' WHERE operator='$category' AND service_id ='$buyer_sku_code' AND tipe='$tipee' AND provider='DF'");
                $db->query("DELETE FROM layanan_pulsa WHERE status='Gangguan'");
                header('location: /admin/setting/provider');
            }
        }
        
    }