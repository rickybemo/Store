<?php

namespace App\Http\Controllers;

use App\Models\Digiflazz;
use App\Models\Kategori;
use App\Models\Layanan;
use Illuminate\Http\Request;

class digiFlazzController extends Controller
{
    public function index()
    {
        $digiflazz = Digiflazz::find(1);
        return view('components.digiflazz', compact('digiflazz'));
    }
    public function change(Request $request)
    {
        $digiflazz = Digiflazz::find(1);
        if ($digiflazz) {
            $digiflazz->username = $request->username;
            $digiflazz->api_key = $request->api_key;
            $digiflazz->save();
            return redirect()->back()->with('success', 'Berhasil mengubah data');
        } else {
            return redirect()->back()->with('error', 'Gagal mengubah data');
        }
    }
    public function order($uid = null, $zone = null, $service = null, $order_id = null)
    {
        $target = $uid . $zone;
        $digiflazz = Digiflazz::find(1);
        $sign = md5($digiflazz->username . $digiflazz->api_key . strval($order_id));
        $api_postdata = array(
            'username' => $digiflazz->username,
            'buyer_sku_code' => $service,
            'customer_no' => "$target",
            'ref_id' => strval($order_id),
            'sign' => $sign,
        );

        $header = array(
            'Content-Type: application/json',
        );

        return $this->connect("/v1/transaction", $api_postdata, $header);
    }

    public function status($poid = null, $pid = null, $uid = null, $zone = null)
    {
        $target = $uid . $zone;
        $digiflazz = Digiflazz::find(1);
        $sign = md5($digiflazz->username . $digiflazz->api_key . strval($poid));
        $header = array(
            'Content-Type: application/json',
        );

        $data = array(
            'command' => 'status-pasca',
            'username' => $digiflazz->username,
            'buyer_sku_code' => $pid,
            'customer_no' => $target,
            'ref_id' => $poid,
            'sign' => $sign
        );

        return $this->connect("/v1/transaction", $data, $header);
    }

    public function harga()
    {
        $digiflazz = Digiflazz::find(1);
        $sign = md5($digiflazz->username . $digiflazz->api_key . "pricelist");
        $data = array(
            'username' => $digiflazz->username,
            'sign' => $sign
        );
        $header = array(
            'Content-Type: application/json',
        );
        $decode = $this->connect('/v1/price-list', $data, $header);
        // $decode = json_decode($service, true);
        if ($decode) {
            // for
            $data = $decode['data'];
            foreach (range(0, count($data) - 1) as $num) {
                $data = $decode['data'][$num];
                $replace = str_replace("&", "dan", $data['category']);
                if ($replace == 'Pulsa') {
                    $untung = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 7.1/100);
                    $seller = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 6.5/100);
                    $api = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 1.25/100);
                } else if ($replace == 'Voucher') {
                    $untung = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 7.1/100);
                    $seller = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 6.5/100);
                    $api = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 5.25/100);
                } else if ($replace == 'Games') {
                    $untung = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 4/100);
                    $seller = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 1.5/100);
                    $api = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 0.10/100);
                } else if ($replace == 'PLN') {
                    $untung = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 7.1/100);
                    $seller = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 6.5/100);
                    $api = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 5.25/100);
                } else if ($replace == 'E-Money') {
                    $untung = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 7.1/100);
                    $seller = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 6.5/100);
                    $api = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 5.1/100);
                } else if ($replace == 'Aktivasi Voucher') {
                    $untung = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 7.1/100);
                    $seller = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 6.5/100);
                    $api = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 5.25/100);
                } else if ($replace == 'Data') {
                    $untung = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 7.1/100);
                    $seller = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 6.5/100);
                    $api = $decode['data'][$num]['price'] + ($decode['data'][$num]['price'] * 5.25/100);
                }
                if ($decode['data'][$num]['seller_product_status'] == true) {
                    $status = 'available';
                    $kat = 'active';
                } else {
                    $status = 'inactive';
                    $kat = 'unactive';
                }
                if ($decode['data'][$num]['type'] == 'Disney+ Hotstar') {
                    $rp = 'Disney Hotstar';
                } else {
                    $rp = $decode['data'][$num]['type'];
                }
                $data = $decode['data'][$num];
                if ($data['brand'] == 'MOBILE LEGENDS') {
                    $brnd = 'Mobile Legends';
                } else {
                    $brnd = $data['brand'];
                }
                if ($data['category'] == 'Games') {
                    $category = 'game';
                } else if ($data['category'] == 'E-Money') {
                    $category = 'ewallet';
                } else {
                    $category = $data['category'];
                }
                $kategori = Kategori::where('nama', $brnd)->first();
                if (!$kategori) {
                    Kategori::create([
                        'nama' => $brnd,
                        'kode' => str_replace(' ', '-', $brnd),
                        'server_id' => 0,
                        'publisher' => 0,
                        'kolom_jumlah' => 0,
                        'status' => $kat,
                        'thumbnail' => 0,
                        'tipe' => $category,
                        'petunjuk' => '0',
                    ]);
                }
                $search = Layanan::where('provider_id', $decode['data'][$num]['buyer_sku_code'])->first();
                if ($search) {
                    $search->harga = $untung;
                    $search->harga_reseller = $seller;
                    $search->harga_vip = $api;
                    $search->status = $status;
                    $search->save();
                } else {
                    $kategori = Kategori::where('nama', $brnd)->first();
                    Layanan::create([
                        'kategori_id' => $kategori->id,
                        'layanan' => $data['product_name'],
                        'provider_id' => $data['buyer_sku_code'],
                        'harga' => $untung,
                        'harga_reseller' => $seller,
                        'harga_vip' => $api,
                        'profit' => 0,
                        'catatan' => $data['desc'],
                        'status' => $status,
                        'provider' => 'digiflazz',
                        'product_logo' => 0,
                    ]);
                }
            }
        }
    }

    public function connect($url, $data, $header)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.digiflazz.com" . $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        $chresult = curl_exec($ch);
        curl_close($ch);
        $json_result = json_decode($chresult, true);
        return $json_result;
    }
}
