<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kategori;
use App\Models\Berita;

class indexController extends Controller
{
    public function create(Request $request)
    {
        if ($request->q) {
            $kategori = Kategori::where('nama', 'LIKE', '%' . $request->q . '%')->where('status', 'active')->get();
        } else {
            $kategori = Kategori::where('status', 'active')->get();
        }

        return view('components.index', [
            'kategori' => $kategori,
            'banner' => Berita::where('tipe', 'banner')->get(),
            'popup' => Berita::where('tipe', 'popup')->latest()->first(),
        ]);
    }

    public function about()
    {
        return view('components.about');
    }

    public function contact()
    {
        return view('components.contact');
    }

    public function pembayaran()
    {
        return view('components.pembayaran');
    }

    public function faq()
    {
        return view('components.faq');
    }
}
