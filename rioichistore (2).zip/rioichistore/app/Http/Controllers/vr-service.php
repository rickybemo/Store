<?php
require '../mainconfig.php';
    $CEK = $db->query("SELECT * FROM provider WHERE code='vip'");
    $vip = $CEK->fetch_assoc();
    $hmem = $db->query("SELECT * FROM options WHERE opt_name='df_harga'");
    $hmems = $hmem->fetch_assoc();
    $hres = $db->query("SELECT * FROM options WHERE opt_name='df_harga_reseller'");
    $hress = $hres->fetch_assoc();
    $hpre = $db->query("SELECT * FROM options WHERE opt_name='df_harga_vip'");
    $hprem = $hpre->fetch_assoc();
    $h2h = $db->query("SELECT * FROM options WHERE opt_name='df_harga_h2hspecial'");
    $h2hh = $h2h->fetch_assoc();
    $results = $curl->connectPost($vip['link'],['key' => $vip['api_key'],'sign' => md5($vip['VIP_APIID'].$VR['VIP_APIKEY']),'provider' => 'service']);
    if(isset($results['data'])){
        foreach($results['data'] as $loop){
            $product = $loop['name'];
            $price = $loop['price']['special'];
            $operator = $loop['game'];
            $sku = $loop['code'];
            $status = $loop['status'];
            $pmember = $price * $hmems['opt_value'] / 100;
            $preseller = $price * $hress['opt_value'] / 100;
            $ppremium = $price * $hprem['opt_value'] / 100;
            $ph2hspecial = $price * $h2hh['opt_value'] / 100;
            $price_member = $price + $pmember;
            $price_reseller = $price + $preseller;
            $price_premium = $price + $ppremium;
            $price_h2hspecial = $price + $ph2hspecial;
            if($status == 'available'){
                $statuss = 'Normal';
            }else if($status == 'empty'){
                $statuss = 'Gangguan';
            }
            $check_data = $db->query("SELECT * FROM layanan_pulsa WHERE operator='$operator' AND service_id='$sku' AND tipe='VGAME' AND provider='VR'");
            if($check_data->num_rows == 0){
                $db->query("INSERT INTO `layanan_pulsa` (`id`, `service_id`, `provider_id`, `operator`, `layanan`, `img`,`min`,`max`,`harga`, `harga_reseller`, `harga_premium`, `harga_h2h`, `profit`, `status`, `provider`, `tipe`, `note`) VALUES ('', '$sku', '$sku', '$operator', '$product', 'null','null','null','$price_member', '$price_reseller', '$price_premium', '$price_h2hspecial', '0', '$statuss', 'VR', 'VGAME', '-')");
                $db->query("DELETE FROM layanans WHERE status='Gangguan'");
                header('location:/admin/setting/provider');
            }else{
                $db->query("UPDATE layanan_pulsa SET status='$statuss', harga='$price_member', harga_reseller='$price_reseller', harga_premium='$price_premium' WHERE operator='$operator' AND service_id ='$sku' AND tipe='VGAME'");
                $db->query("DELETE FROM layanan_pulsa WHERE status='Gangguan'");
                header('location: /admin/setting/provider');
            }
        }
    }