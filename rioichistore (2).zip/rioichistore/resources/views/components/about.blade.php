@extends('../main')

@section('content')
<div class="container-fluid">
  <div class="checkout-tabs">
  <div class="row">
  <div class="col-lg-2">
  <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
  <a href="{{ url('about') }}" class="nav-link active">
  <i class="fas fa-address-card d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Tentang Kami</p>
  </a>
  <a href="{{ url('contact') }}" class="nav-link">
  <i class="fas fa-address-book d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Kontak Kami</p>
  </a>
  <a href="{{ url('pembayaran') }}" class="nav-link">
  <i class="fas fa-tags d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Pembayaran</p>
  </a>
  <a href="{{ url('faq') }}" class="nav-link">
  <i class="bx bx-question-mark d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">FAQ</p>
  </a>
  </div>
  </div>
  <div class="col-lg-10">
  <div class="card">
  <div class="card-body">
  <div class="tab-content" id="v-pills-tabContent">
  <div class="tab-pane fade show active" id="v-pills-gen-ques" role="tabpanel" aria-labelledby="v-pills-gen-ques-tab">
  <h4 class="card-title mb-5">Tentang Kami</h4>
  <p align="justify"> {{ ENV('APP_NAME') }} merupakan jasa penyedia TopUp Game Online termurah, Proses cepat serta open 24 Jam dengan pembayaran terlengkap di Indonesia. Nikmati pengalaman pembelian tanpa repot untuk membeli kredit game di {{ ENV('APP_NAME') }}, platform top-up terbaik untuk game. Kami menyediakan pembayaran yang lengkap, menawarkan harga yang sangat terjangkau dan proses yang sangat cepat. Sultankan akunmu bersama {{ ENV('APP_NAME') }} </p>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
  </div>
@endsection