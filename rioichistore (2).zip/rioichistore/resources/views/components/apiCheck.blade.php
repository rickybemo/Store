@extends('main-admin')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Konfigurasi ApiChecker</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">/konfigurasi/apicheck</li>
                </ol>
            </div>
        </div>
    </div>
</div>
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@elseif(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
<div class="card">
    <div class="card-body">
        <h4 class="mb-3 header-title mt-0">Konfig</h4>
        <form action="{{ url('apicheck/change') }}" method="POST">
            @csrf
            <div class="form-group">
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label" for="example-fileinput">Rioichi</label>
                    <div class="col-lg-10">
                        <input type="text" name="rioichi" id="rioichi" @if (isset($rioichi->key))
                        value="{{ $rioichi->key }}"
                        @else
                        value="{{ old('rioichi') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label">LolHuman</label>
                    <div class="col-lg-10">
                        <input type="text" name="lolhuman" id="lolhuman" @if (isset($lolhuman->key))
                        value="{{ $lolhuman->key }}"
                        @else
                        value="{{ old('key') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>
@endsection