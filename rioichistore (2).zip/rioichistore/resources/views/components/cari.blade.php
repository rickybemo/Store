@extends('main')

@section('css')
<style>
    .form-check-input:focus {
        border-color: #fe6c17;
        box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
        outline: 0;
    }

    .form-check-input:checked {
        background-color: #fe6c17;
        border-color: #fe6c17;
    }

    .btn-primary {
        background-color: #3571e2;
        border-color: #3571e2;
        cursor: pointer;
        color: #fff;
    }

    .btn-primary:hover {
        color: #fff;
        background-color: #3571e2;
        border-color: #3571e2;
    }

    .btn-primary:focus,
    .btn-primary.focus {
        color: #fff;
        background-color: #3571e2;
        border-color: #3571e2;
        box-shadow: 0 0 0 0.2rem rgba(255, 168, 38, 0.5);
    }

    #searchProds {
        width: 60px;
        transition: width .5s ease
    }

    #searchProds:focus {
        width: 240px
    }
</style>
@endsection

@section('content')
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@elseif(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
<div class="wrapper pt-4">
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto mb-5">
                <div class="card bg-dark shadow">
                    <div class="card-header">
                        <h5>Cek Status Transaksi</h5>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('cari.post') }}" method="post">
                            @csrf
                            Masukkan No Invoice :
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-receipt"></i></span>
                                <input type="text" name="id" id="id" class="form-control" placeholder="No Invoice">
                            </div>
                            <button class="btn btn-outline-primary mt-3 float-end">Check</button>
                             <br>atau bisa akses melalui : 
                            <br><font color='#0082e9'>pripunstoree.com/pembelian/invoice/(no invoice)</font>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection