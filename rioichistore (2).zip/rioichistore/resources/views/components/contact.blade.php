@extends('../main')

@section('content')
<div class="container-fluid">
  <div class="checkout-tabs">
  <div class="row">
  <div class="col-lg-2">
  <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
  <a href="{{ url('about') }}" class="nav-link ">
  <i class="fas fa-address-card d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Tentang Kami</p>
  </a>
  <a href="{{ url('contact') }}" class="nav-link active">
  <i class="fas fa-address-book d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Kontak Kami</p>
  </a>
  <a href="{{ url('pembayaran') }}" class="nav-link">
  <i class="fas fa-tags d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Pembayaran</p>
  </a>
  <a href="{{ url('faq') }}" class="nav-link">
  <i class="bx bx-question-mark d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">FAQ</p>
  </a>
  </div>
  </div>
  <div class="col-lg-10">
    <div class="card">
    <div class="card-body">
    <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-gen-ques" role="tabpanel" aria-labelledby="v-pills-gen-ques-tab">
    <h4 class="card-title mb-5">Kontak Kami</h4>
    <div class="table-responsive">
    <table class="table table-nowrap mb-0">
    <tbody>
    <tr>
    <th scope="row">Instagram :</th>
    <td><a href="https://instagram.com/riopratamaputra43">Rio Pratama Putra</a></td>
    </tr>
    <tr>
    <th scope="row">Whatsapp :</th>
    <td><a href="wa.me/6285714828982">Rioichi Store</a></td>
     </tr>
    <tr>
    <th scope="row">YouTube :</th>
    <td><a href="https://www.youtube.com/@rioichitv">Rioichi TV</a></td>
    </tr>
    </tbody>
    </table>
    </div>
    <div class="mt-4 text-center">
    <ul class="list-inline">
    <li class="list-inline-item">
    <a href="wa.me/6285714828982" class="social-list-item bg-success text-white border-success ">
    <i class="fab fa-whatsapp"></i>
    </a>
    </li>
    <li class="list-inline-item">
    <a href="https://www.youtube.com/@rioichitv" class="social-list-item bg-dark text-white border-dark">
    <i class="fab fa-youtube"></i>
    </a>
    </li>
    <li class="list-inline-item">
    <a href="https://instagram.com/riopratamaputra43" class="social-list-item bg-danger text-white border-danger">
    <i class="mdi mdi-instagram"></i>
    </a>
    </li>
    </ul>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
  </div>
  </div>
  </div>
@endsection('content')