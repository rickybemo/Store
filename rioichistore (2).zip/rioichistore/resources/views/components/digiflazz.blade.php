@extends('main-admin')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Konfigurasi Digiflazz</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">/konfigurasi/digiflazz</li>
                </ol>
            </div>
        </div>
    </div>
</div>
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@elseif(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
<div class="card">
    <div class="card-body">
        <h4 class="mb-3 header-title mt-0">Konfig</h4>
        <form action="{{ url('digiflazz/change') }}" method="POST">
            @csrf
            <div class="form-group">
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label" for="example-fileinput">Username Digiflazz</label>
                    <div class="col-lg-10">
                        <input type="text" name="username" id="username" @if (isset($digiflazz->username))
                        value="{{ $digiflazz->username }}"
                        @else
                        value="{{ old('username') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label">Api Key</label>
                    <div class="col-lg-10">
                        <input type="text" name="api_key" id="api_key" @if (isset($digiflazz->api_key))
                        value="{{ $digiflazz->api_key }}"
                        @else
                        value="{{ old('api_key') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <div class="float-end">
                         <a class="btn btn-primary float-end" href="/get/digiflazz">Get Layanan</a>
                                </div>
        </form>
    </div>
</div>
@endsection