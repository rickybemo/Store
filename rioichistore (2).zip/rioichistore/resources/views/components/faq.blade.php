@extends('../main')

@section('content')
<div class="container-fluid">
  <div class="checkout-tabs">
  <div class="row">
  <div class="col-lg-2">
  <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
  <a href="{{ url('about') }}" class="nav-link ">
  <i class="fas fa-address-card d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Tentang Kami</p>
  </a>
  <a href="{{ url('contact') }}" class="nav-link">
  <i class="fas fa-address-book d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Kontak Kami</p>
  </a>
  <a href="{{ url('pembayaran') }}" class="nav-link ">
  <i class="fas fa-tags d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Pembayaran</p>
  </a>
  <a href="{{ url('faq') }}" class="nav-link active">
  <i class="bx bx-question-mark d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">FAQ</p>
  </a>
  </div>
  </div>
  <div class="col-lg-10">
    <div class="card">
    <div class="card-body">
    <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-gen-ques" role="tabpanel" aria-labelledby="v-pills-gen-ques-tab">
    <h4 class="card-title mb-5">FAQ</h4>
    <div class="faq-box d-flex mb-4">
    <div class="flex-shrink-0 me-3 faq-icon">
    <i class="bx bx-help-circle font-size-20 text-success"></i>
    </div>
    <div class="flex-grow-1">
    <h5 class="font-size-15">Apakah terpercaya?</h5>
    <p class="text-muted">Kami tidak pernah punya niat menipu customer kami & Kami juga sudah direkomendasikan oleh berbagai youtuber gaming, proplayer, dan influencer terkenal.</p>
    </div>
    </div>
    <div class="faq-box d-flex mb-4">
    <div class="flex-shrink-0 me-3 faq-icon">
    <i class="bx bx-help-circle font-size-20 text-success"></i>
    </div>
    <div class="flex-grow-1">
    <h5 class="font-size-15">Apakah top up di AMAN?</h5>
    <p class="text-muted">Sudah pasti aman 100% dan pastinya legal karena kami tidak menjual produk ilegal, jika terbukti produk yang kami jual ilegal kami siap mengembalikan uang anda secara utuh 100%.</p>
    </div>
    </div>
    <div class="faq-box d-flex mb-4">
    <div class="flex-shrink-0 me-3 faq-icon">
    <i class="bx bx-help-circle font-size-20 text-success"></i>
    </div>
    <div class="flex-grow-1">
    <h5 class="font-size-15">Apakah perlu menghubungi CS setelah melakukan pembayaran?</h5>
    <p class="text-muted">Kamu tidak perlu menghubungi CS karena sistem kami sudah berjalan secara otomatis mohon menunggu sesuai estimasi yang tersedia pada keterangan produk</p>
    </div>
    </div>
    <div class="faq-box d-flex mb-4">
    <div class="flex-shrink-0 me-3 faq-icon">
    <i class="bx bx-help-circle font-size-20 text-success"></i>
    </div>
    <div class="flex-grow-1">
    <h5 class="font-size-15">Bagaimana jika saldo game kami tidak bertambah setelah menunggu sesuai estimasi produk?</h5>
    <p class="text-muted">Apabila anda sudah menunggu sesuai estimasi produk, Namun saldo game belum bertambah, Silahkan hubungi CS kami.</p>
    </div>
    </div>
    <div class="faq-box d-flex mb-4">
    <div class="flex-shrink-0 me-3 faq-icon">
    <i class="bx bx-help-circle font-size-20 text-success"></i>
    </div>
    <div class="flex-grow-1">
    <h5 class="font-size-15">Kapan saldo game saya akan bertambah?</h5>
    <p class="text-muted">Setelah pembayaran kalian terkonfirmasi oleh sistem kami saldo game anda akan bertambah secara otomatis.</p>
    </div>
    </div>
    <div class="faq-box d-flex mb-4">
    <div class="flex-shrink-0 me-3 faq-icon">
    <i class="bx bx-help-circle font-size-20 text-success"></i>
    </div>
    <div class="flex-grow-1">
    <h5 class="font-size-15">Kapan pembayaran kami akan terkonfirmasi oleh sistem?</h5>
    <p class="text-muted">Untuk semua pembayaran akan terkonfirmasi dalam hitungan menit, kecuali pembayaran Transfer BANK membutuhkan waktu ± 5-15 MENIT.</p>
    </div>
    </div>
    <div class="faq-box d-flex mb-4">
    <div class="flex-shrink-0 me-3 faq-icon">
    <i class="bx bx-help-circle font-size-20 text-success"></i>
    </div>
    <div class="flex-grow-1">
    <h5 class="font-size-15">Apa yang harus saya lakukan jika salah transfer?</h5>
    <p class="text-muted">Pembayaran harus pas dan sesuai dengan rekening dan nominal yang tertera, agar sistem cek pembayaran otomatis berjalan. Apabila salah transfer slahkan hubungi CS kami.</p>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
  </div>
  </div>
  </div>
@endsection('content')