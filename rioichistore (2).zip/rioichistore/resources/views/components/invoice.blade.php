@extends('../main')

@section('content')
<div class="container-fluid">
  <div class="row">
  <div class="col-lg-12">
  <div class="card mb-2">
  <div class="card-header">
  <h5 class="card-title">Nomor Invoice: {{ $data->id_pembelian }}</h5>
  <p>Simpan Nomor Invoice Untuk Cek Pesanan </p>
  </div>
  <div class="card-body">
  <div class="hurry-up-area">
  <p>Untuk menyelesaikan proses transaksi, silahkan lakukan pembayaran sejumlah:</p>
  <b class="price-large with-floating">
  Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}
  <span class="floating-bottom"><strong>PENTING!</strong> Transfer yang benar, Jangan lebih, Jangan kurang,<strong> HARUS SESUAI !!!</strong></span>
  </b>
  </div>
  </div>
  </div>
  </div>
  </div>
  <div class="row">
  <div class="col-lg-6">
  <div class="card mt-3">
  <div class="card-header">
  <h5 class="card-title"><img src="{{ asset('/assets/img/payment/') }}/{{ $data->metode_pembayaran }}.png" width="100px"></h5>
  </div>
  <div class="card-body">
  <div class="text-center">
  <h5>Nominal Pembayaran</h5>
  <h2><b>Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }} </b><i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy('{{ $data->harga_pembayaran }}', this)" class="fas fa-copy"></i></h2> <br>
  </div>
  @if($data->metode_pembayaran == "Saldo")
  <div class="text-center">
  <h5>Terima Kasih Telah Order.</h5>
  </div>
  @else
  <div class="text-center">
  <h5>Batas Waktu Pembayaran</h5>
  <h2><b class="batas-pembayaran"></b><h2><br>
  </div>
  @endif
  @if($data->metode_pembayaran == "bcatf")
  <div class="text-center">
    <h5>Kerekening Berikut ini:</h5>
    </div>
    <div class="rekening-detil">
    <div class="head-logo">
    <img src="{{ asset('/assets/img/payment/') }}/{{ $data->metode_pembayaran }}.png" width="100px" alt="Bank BCA">
    </div>
    <div class="body-rekening">
    <table>
     <tbody>
    <tr>
    <td>Nomor Rekening:</td>
    <td>@php echo preg_replace('/[^0-9]/', '', $data->no_pembayaran) @endphp <i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy('{{ $data->no_pembayaran }}', this)" class="fas fa-copy"></i></td>
    </tr>
    <tr>
    <td>Atas Nama:</td>
    <td>Rio Pratama Putra</td>
    </tr>
    </tbody>
    </table>
    </div>
    </div>
    @elseif($data->metode_pembayaran == "alfamart")
  <div class="text-center">
    <h5>Kerekening Berikut ini:</h5>
    </div>
    <div class="rekening-detil">
    <div class="head-logo">
    <img src="{{ asset('/assets/img/payment/') }}/{{ $data->metode_pembayaran }}.png" width="100px" alt="Bank BCA">
    </div>
    <div class="body-rekening">
    <table>
     <tbody>
    <tr>
    <td>Nomor Rekening:</td>
    <td>@php echo preg_replace('/[^0-9]/', '', $data->no_pembayaran) @endphp <i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy('{{ $data->no_pembayaran }}', this)" class="fas fa-copy"></i></td>
    </tr>
    <tr>
    <td>Atas Nama:</td>
    <td>PLASAMALL</td>
    </tr>
    </tbody>
    </table>
    </div>
    </div>
    @elseif($data->metode_pembayaran == "indomaret")
  <div class="text-center">
    <h5>Kerekening Berikut ini:</h5>
    </div>
    <div class="rekening-detil">
    <div class="head-logo">
    <img src="{{ asset('/assets/img/payment/') }}/{{ $data->metode_pembayaran }}.png" width="100px" alt="Bank BCA">
    </div>
    <div class="body-rekening">
    <table>
     <tbody>
    <tr>
    <td>Nomor Rekening:</td>
    <td>@php echo preg_replace('/[^0-9]/', '', $data->no_pembayaran) @endphp <i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy('{{ $data->no_pembayaran }}', this)" class="fas fa-copy"></i></td>
    </tr>
    <tr>
    <td>Atas Nama:</td>
    <td>Linkita</td>
    </tr>
    </tbody>
    </table>
    </div>
    </div>
  @elseif($data->metode_pembayaran == "qris")
    <div class="text-center">
      <h5>Scan Kode QR Berikut ini:</h5>
      <h2><a href="{{ $data->no_pembayaran }}" target="blank" class="btn btn-primary">LIHAT QRIS</a></h2>
    </div>
   @elseif($data->metode_pembayaran == "Saldo")
  <div class="text-center">
    </div>
    <div class="rekening-detil">
    <div class="head-logo">
    <img src="{{ asset('/assets/img/payment/') }}/{{ $data->metode_pembayaran }}.png" width="100px" alt="Bank Transfer">
    </div>
    <div class="body-rekening">
    <table>
     <tbody>
    </tbody>
    </table>
    </div>
    </div>
  @else
  <div class="text-center">
    <h5>Kerekening Berikut ini:</h5>
    </div>
    <div class="rekening-detil">
    <div class="head-logo">
    <img src="{{ asset('/assets/img/payment/') }}/{{ $data->metode_pembayaran }}.png" width="100px" alt="Bank Transfer">
    </div>
    <div class="body-rekening">
    <table>
     <tbody>
    <tr>
    <td>Nomor Rekening:</td>
    <td>@php echo preg_replace('/[^0-9]/', '', $data->no_pembayaran) @endphp <i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy('{{ $data->no_pembayaran }}', this)" class="fas fa-copy"></i></td>
    </tr>
    <tr>
    <td>Atas Nama:</td>
    <td>Rioichi Store</td>
    </tr>
    </tbody>
    </table>
    </div>
    </div>
  @endif
  
  <hr>
  <div class="text-center">
  <h5>Intruksi Pembayaran</h5>
  </div>
  @if($data->metode_pembayaran == "qris")
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
    <button class="accordion-button fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
      Pembayaran Via Qris menggunakan 1 HP
    </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
    <div class="accordion-body">
    <div class="text-muted">
    <p>
    1.
    Screenshot kode QR yang tampil<br>
    2.
    Masuk ke aplikasi dompet digital Anda yang telah mendukung QRIS seperti (Dana, Gopay, Ovo, Shopeepay, Link aja, Dll)<br>
    3.
    Buka Scan QR pada aplikasi dompet digital anda<br>
    4.
    Scan QR yang muncul pada halaman pembelian anda/ Pilih dari galeri hasil screenshot kode QR<br>
    5.
    Akan muncul detail transaksi. Pastikan data transaksi sudah sesuai<br>
    6.
    Selesaikan proses pembayaran Anda<br>
    7.
    Transaksi selesai. Simpan bukti pembayaran Anda<br>
    </p>
    </div>
    </div>
    </div>
    </div>
    @elseif($data->metode_pembayaran == "alfamart")
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
    <button class="accordion-button fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
    Pembayaran Via ALFA GROUP
    </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
    <div class="accordion-body">
    <div class="text-muted">
    <p>
1.
Datang ke Alfamart/Alfa Express/ Dandan/ Lawson<br>
2.
Sampaikan ke kasir ingin melakukan pembayaran <b>PLASAMALL</b><br>
3.
Berikan kode bayar <b>@php echo preg_replace('/[^0-9]/', '', $data->no_pembayaran) @endphp</b> ke kasir<br>
4.
Bayar sesuai jumlah yang diinfokan oleh kasir<br>
5.
Simpan struk bukti pembayaran Anda<br>
    </p>
    </div>
    </div>
    </div>
    </div>
    @elseif($data->metode_pembayaran == "indomaret")
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
    <button class="accordion-button fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
    Pembayaran Via INDOMARET
    </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
    <div class="accordion-body">
    <div class="text-muted">
    <p>
1.
Datang ke gerai Indomaret<br>
2.
Sampaikan ke kasir ingin melakukan pembayaran <b>Linkita</b><br>
3.
Berikan kode bayar <b>@php echo preg_replace('/[^0-9]/', '', $data->no_pembayaran) @endphp</b> ke kasir<br>
4.
Bayar sesuai jumlah yang diinfokan oleh kasir<br>
5.
Simpan struk bukti pembayaran Anda<br>
    </p>
    </div>
    </div>
    </div>
    </div>
    @elseif($data->metode_pembayaran == "Saldo")
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
    <button class="accordion-button fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
    Pembayaran Via Saldo
    </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
    <div class="accordion-body">
    <div class="text-muted">
    <p>
1.
Login ke Akun Anda<br>
2.
Pilih Game Yang ingin di Top Up<b></b><br>
3.
Beli dan Simpan Invoice<br>
4.
Pastikan Saldo anda cukup!<br>
    </p>
    </div>
    </div>
    </div>
    </div>
  @else
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
    <button class="accordion-button fw-medium collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
    Pembayaran Via Transfer Bank
    </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="">
    <div class="accordion-body">
    <div class="text-muted">
    <p>
    1.
    Wajib mengirim uang dengan nominal <b> Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }} </b> <br>
    2.
    Apabila nominal salah orderan akan diproses lama/ Tidak otomatis masuk<br>
    3.
    Transfer bisa dilakukan menggunakan dari semua Bank <br>
    4.
    Apabila sudah transfer tinggal menunggu 1-10 menit untuk proses verifikasi pembayaran<br>
    5.
    Apabila sudah lewat dari 30 menit dan orderan belum masuk, silahkan hubungi admin di whatsapp<br>
    6.
    Selesaikan proses pembayaran Anda<br>
    7.
    Transaksi selesai. Simpan bukti pembayaran Anda<br>
    </p>
    </div>
    </div>
    </div>
    </div>
  @endif
  
  </div>
  </div>
  </div>
  <div class="col-lg-6">
  <div class="card mt-3">
  <div class="card-body">
  <div class="table-responsive">
  <table class="table mb-0 table-bordered">
  <tbody>
      <tr>
  <td>Nickname</td>
  <th>{{ $data->nickname }}</th>
  </tr>
   <tr>
  <td>Nama Produk</td>
  <th>{{ $data->layanan }}</th>
  </tr>
  <tr>
  <td>Data ID</td>
  <th>
    {{ $data->user_id }}  {{ $data->zone != null ? "(".$data->zone.")" : ''  }}
  </th>
  </tr>
  <tr>
  <td>Harga</td>
  <th>Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }} </th>
  </tr>
  <tr>
@if($data->metode_pembayaran == "bcatf")      
<tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp 1.000 </th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>
@elseif($data->metode_pembayaran == "gopay") 
<tr>
    <tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp 1.000</th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>

@elseif($data->metode_pembayaran == "Saldo") 
<tr>
    <tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp. 0 </th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>

    @elseif($data->metode_pembayaran == "ovo") 
<tr>
    <tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp 1.000 </th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>
@elseif($data->metode_pembayaran == "qris") 
<tr>
    <tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp 1.000</th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>
@elseif($data->metode_pembayaran == "alfamart") 
<tr>
    <tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp 4.000</th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>
@elseif($data->metode_pembayaran == "indomaret") 
<tr>
    <tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp 4.000</th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>
@else
<tr>
    <tr id="collapse2" class="table-warning accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample" style="transition: height 00s ease;">
<td>Pajak</td>
<th>Rp 4.000</th>
</tr>
<tr class="table-success collapsed">
<td>Total Pembayaran</td>
<th>
<p class="mb-1">Rp. {{ number_format($data->harga_pembayaran, 0, ',','.') }}<i data-toggle="tooltip" data-placement="bottom" title="Copy to clipboard" data-container="body" onclick="copy({{ number_format($data->harga_pembayaran, 0, ',','.') }}, this)" class="fas fa-copy"> </i></p>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse show" style="transition: height 00s ease;">Lihat Rincian</text>
<text data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapse2" id="collapse2" class="text-primary mb-0 accordion-collapse collapse" style="transition: height 00s ease;">Tutup Rincian</text>
</th>
</tr>
@endif
  <tr>
  <td>Waktu Pesanan</td>
  <th> {{ $data->created_at }} </th>
  </tr>
  <tr>
  <td>Waktu Expired</td>
  <th> {{ $expired }} </th>
  </tr>
  <tr>
  <td>Status</td>
  <th>
    @if($data->status_pembayaran == "Belum Lunas" && $data->status_pembelian == "Menunggu")
      <span class="badge badge-pill badge-soft-primary font-size-12">Menunggu Pembayaran</span>
      @elseif($data->status_pembayaran == "Belum Lunas" && $data->status_pembelian == "Success")
      <span class="badge badge-pill badge-soft-success font-size-12">Success</span>
    @elseif($data->status_pembayaran == "Lunas" && $data->status_pembelian == "Pending" || $data->status_pembayaran == "Lunas" && $data->status_pembayaran == "Menunggu")
      <span class="badge badge-pill badge-soft-success font-size-12">Success</span>
    @elseif($data->status_pembayaran == "Lunas" && $data->status_pembelian == "Processing")
      <span class="badge badge-pill badge-soft-info font-size-12">Diproses</span>
    @elseif($data->status_pembayaran == "Lunas" && $data->status_pembelian == "Success")
      <span class="badge badge-pill badge-soft-success font-size-12">Success</span>
    @elseif($data->status_pembayaran == "Batal" && $data->status_pembelian == "Batal")
      <span class="badge badge-pill badge-soft-danger font-size-12">Dibatalkan</span>
      @elseif($data->status_pembayaran == "Lunas" && $data->status_pembelian == "Batal")
      <span class="badge badge-pill badge-soft-danger font-size-12">Dibatalkan</span>
      @elseif($data->status_pembayaran == "Belum Lunas" && $data->status_pembelian == "Error")
      <span class="badge badge-pill badge-soft-danger font-size-12">Dibatalkan</span>
    @endif
  </th>
  </tr>
  <tr>
  <td>SN</td>
  <th> {{ $data->sn ? $data->sn : "-" }} </th>
  </tr>
  </tbody>
  </table>
  </div>
  </div>
  </div>
  </div>
  </div>
  
  @push('script-lib')
  <script src="https://cdn.jsdelivr.net/npm/js-cookie@3.0.1/dist/js.cookie.min.js"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
  <script type="text/javascript">
    mybutton = document.querySelector(".act-btn-top");
    window.onscroll = function() {
        scrollFunc()
    };

    function scrollFunc() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }

    function toTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>
<script>
    function copy(text, elem) {
        var input = document.createElement('textarea');
        input.innerHTML = text;
        document.body.appendChild(input);
        input.select();
        var result = document.execCommand('copy');
        document.body.removeChild(input);

        $(elem).removeClass("fa-copy").addClass("fa-check-double").attr("style", "color: #4caf50;");
        $(elem).attr("title", "Copied!").tooltip("_fixTitle").tooltip("show").attr("title", "Copy to clipboard").tooltip("_fixTitle");

        setTimeout(() => {
            $(elem).removeClass("fa-check-double").addClass("fa-copy").removeAttr("style");
        }, 3000);
        // return result;
    }
      function CountDownDewek(){
        var endDate = moment('{{ $expired }}', 'YYYY-MM-DD HH:mm:ss').toDate();
        var countDownDate = endDate.getTime();

        // Update the count down every 1 second
        var x = setInterval(function() {
            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Display the result in the element with id="demo"
            $('.batas-pembayaran').html(('0' + hours).slice(-2) + " jam " +('0' + minutes).slice(-2) + " menit " + ('0' + seconds).slice(-2) + " detik");

            // If the count down is finished, write some text
            if (distance < 0) {
                clearInterval(x);
                $('.batas-pembayaran').html("EXPIRED");
            }
        }, 1000);
    }

    $(document).ready(function(){
        CountDownDewek();
        $('[data-toggle="tooltip"]').tooltip();
    });
  </script>
  @endpush
@endsection