@extends('main-admin')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Konfigurasi Ipaymu</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">/konfigurasi/ipaymu</li>
                </ol>
            </div>
        </div>
    </div>
</div>
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@elseif(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
<div class="card">
    <div class="card-body">
        <h4 class="mb-3 header-title mt-0">Konfig</h4>
        <form action="{{ url('ipaymu/change') }}" method="POST">
            @csrf
            <div class="form-group">
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label" for="example-fileinput">VA</label>
                    <div class="col-lg-10">
                        <input type="text" name="va" id="va" @if (isset($ipaymu->va))
                        value="{{ $ipaymu->va }}"
                        @else
                        value="{{ old('va') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label">Key</label>
                    <div class="col-lg-10">
                        <input type="text" name="key" id="key" @if (isset($ipaymu->key))
                        value="{{ $ipaymu->key }}"
                        @else
                        value="{{ old('key') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</div>
@endsection