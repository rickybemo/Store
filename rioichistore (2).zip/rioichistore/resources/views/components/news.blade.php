@extends("main")

@section("content")
<div class="wrapper pt-4">
    <div class="container mb-5">
        <div class="row mt-1">
            <div class="col-12">
                <div class="card mt-1 bg-white shadow-lg mt-1 text-white">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-12">
                                <h4 class="page-title text-dark">Berita & Promo</h4>
                            </div>
                            
                                    <ul class="dropdown-menu dropdown-menu-dark position-absolute shadow navbar-nav-scroll" aria-labelledby="dropsearchdown" id="dropDownSearchResults"></ul>
                                </form>                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="row">
                    @forelse($datas as $data)
                    <div class="col-md-3 col-12 mt-3">
                        <div class="card mt-1 bg-white shadow-lg mt-1 text-white" style="height:70%">
                            <div class="card-body">
                                <img src="{{ $data->thumbnail }}" class="img-fluid" style="height:50%">
                                
                                <h5 class="text-truncate mt-2">{{ $data->title }}</h5>
                                <div class="text-end mt-2 mb-2">
                                    @php
                                    if($data->type == "promo"){
                                        $bg = "info";
                                    }else{
                                        $bg = "warning";
                                    }
                                    @endphp
                                    <span class="badge bg-{{ $bg }} text-uppercase">{{ $data->type }}</span>
                                </div>
                                <a href="{{ route('user.news.show', [$data->slug]) }}" class="btn btn-primary position-absolute bottom-0 start-50 translate-middle-x">Baca Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="col-12">
                        <h3 class="text-center text-dark">Berita Belum Tersedia.</h3>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</div>
@endsection