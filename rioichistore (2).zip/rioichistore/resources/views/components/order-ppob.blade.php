@extends('../main')

@section("title", $title." -")

@section('content')
<div class="row mt-3 justify-content-center">
    <div class="col-12 col-md-3">
        <div class="card light">
            <div class="card-body">
                <img src="{{ $kategori->thumbnail }}" style="max-width:300px; max-height:200px" class="rounded product" alt="ml">
                <h5 class="m-0 mt-1 fs-14 fw-bold text-dark">{{ $kategori->nama }}</h5>
                <br>
                <span class="text-dark">TopUp {{$kategori->nama }} </span><br>
                <p>Cara Order : </p>
                <ol class="text-dark">
                    <li>Masukkan Nomor HP Anda</li>
                    <li>Pilih Nominal Yang Akan Diisi</li>
                    <li>Pilih Metode Pembayaran</li>
                    <li>Isi Data Yang Diperlukan</li>
                    <li>Klik Beli & Lakukan Pembayaran</li>
                </ol>
            </div>
        </div>
        <div class="card light">
            <div class="card-body text-center">
                <h5 class="m-0 mt-1 fs-14 fw-bold text-dark">Estimasi Proses Otomatis 1-3 Menit</h5>
                <marquee>
                    <h5 class="m-0 mt-1 fs-14 fw-bold text-dark">Event Maximal 120 Menit</h5>
                </marquee>
                <h5 class="m-0 mt-1 fs-14 fw-bold text-success">Layanan Aktif 24 Jam!</h5>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-6">
        <div class="card light">
            <div class="card-body">
                <h4 class="text-dark mb-3 mt-0 fw-bold">1. Lengkapi data</h4>
                <div class="row">
                    <div class="col-12">
                        <div class="mb-3">
                            <input type="number" class="form-control" id="nomorTarget" placeholder="08xxx">
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- end card -->
        <div class="card light">
            <div class="card-body">
                <h4 class="text-dark mb-3 mt-0 fw-bold">2. Pilih Nominal</h4>
                <div class="row text-center" id="listLayanan">
                    <h3 class="text-muted">Silakan isi nomor hp</h3>
                </div>
            </div>
        </div> <!-- end card -->
        <div class="card light">
            <div class="card-body">
                <h4 class="text-dark mb-3 mt-0 fw-bold">3. Pilih Tipe Pembayaran</h4>
                <div class="row">
                    <div class="mt-2">
                        <a href="" class="text-white collapsed" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <div class="card-header card-custom" id="headingOne">
                                <h5 class="m-0 fs-16 fw-light text-dark">
                                    Ewallet
                                    <i class="uil uil-angle-down float-end accordion-arrow"></i>
                                </h5>
                            </div>
                        </a>
                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                            <input type="radio" class="btn-check" name="pembayaran" id="qris" autocomplete="off" value="QRISC">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="qris">
                                <img class="img-fluid " width="30%" height="2%" src="/assets/image/qris.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="QRIS"></span>
                                </p>
                            </label>
                            <input type="radio" class="btn-check" name="pembayaran" id="ovo" autocomplete="off" value="ovo">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="ovo">
                                <img class="img-fluid " width="30%" height="2%" src="/assets/image/ovo.jpg">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="OVO"></span>
                                </p>
                            </label>
                            <input type="radio" class="btn-check" name="pembayaran" id="gopay" autocomplete="off" value="gopay">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="gopay">
                                <img class="img-fluid " width="30%" height="2%" src="https://1.bp.blogspot.com/-HWNpI1A87vw/XJNq8llVlnI/AAAAAAAAAa8/5PpRCSJVjQQCLrVW4DMYobzCQRlzFj2BQCLcBGAs/s1600/Logo%2BGoPay%2BVector%2BCDR%2Bdan%2BPNG.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="GOPAY"></span>
                                </p>
                            </label>
                        </div>
                    </div>
                    <div class="mt-2">
                        <a href="" class="text-dark collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <div class="card-header card-custom" id="headingTwo">
                                <h5 class="m-0 fs-16 fw-light text-dark">
                                    Convenience Store
                                    <i class="uil uil-angle-down float-end accordion-arrow"></i>
                                </h5>
                            </div>
                        </a>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                            <input type="radio" class="btn-check" name="pembayaran" id="alfamart" autocomplete="off" value="ALFAMART">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="alfamart">
                                <img class="img-fluid " width="30%" height="2%" src="/assets/image/alfamart.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="ALFAMART"></span>
                                </p>
                            </label>
                            <input type="radio" class="btn-check" name="pembayaran" id="indomaret" autocomplete="off" value="INDOMARET">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="indomaret">
                                <img class="img-fluid " width="30%" height="2%" src="https://upload.wikimedia.org/wikipedia/commons/9/9d/Logo_Indomaret.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="INDOMARET"></span>
                                </p>
                            </label>
                        </div>
                    </div>
                    <div class="mt-2">
                        <a href="" class="text-dark collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            <div class="card-header card-custom" id="headingThree">
                                <h5 class="m-0 fs-16 fw-light text-dark">
                                    Virtual Account
                                    <i class="uil uil-angle-down float-end accordion-arrow"></i>
                                </h5>
                            </div>
                        </a>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                            <input type="radio" class="btn-check" name="pembayaran" id="bca" autocomplete="off" value="BCAVA">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="bca">
                                <img class="img-fluid " width="30%" height="2%" src="https://bobontopup.com/assets/images/payment/bca.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="BCA"></span>
                                </p>
                            </label>
                            <input type="radio" class="btn-check" name="pembayaran" id="bni" autocomplete="off" value="BNIVA">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="bni">
                                <img class="img-fluid " width="30%" height="2%" src="https://bobontopup.com/assets/images/payment/bni.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="BNI"></span>
                                </p>
                            </label>
                            <input type="radio" class="btn-check" name="pembayaran" id="mandiri" autocomplete="off" value="MANDIRIVA">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="mandiri">
                                <img class="img-fluid " width="30%" height="2%" src="/assets/image/mandiri.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="MANDIRI"></span>
                                </p>
                            </label>
                            <input type="radio" class="btn-check" name="pembayaran" id="permata" autocomplete="off" value="PERMATAVA">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="permata">
                                <img class="img-fluid " width="30%" height="2%" src="/assets/image/permata.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="PERMATA"></span>
                                </p>
                            </label>
                        </div>
                    </div>
                    @auth
                    <div class="mt-2">
                        <a href="" class="text-dark collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            <div class="card-header card-custom" id="headingFour">
                                <h5 class="m-0 fs-16 fw-light text-dark">
                                    Saldo
                                    <i class="uil uil-angle-down float-end accordion-arrow"></i>
                                </h5>
                            </div>
                        </a>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                            <input type="radio" class="btn-check" name="pembayaran" id="saldo" autocomplete="off" value="Saldo">
                            <label class="btn btn-secondary d-block mt-2 text-start but" for="saldo">
                                <img class="img-fluid " width="30%" height="2%" src="https://bobontopup.com/assets/images/payment/bca.png">
                                <p class="float-end d-inline-block">
                                    <span class="badge bg-primary" id="SALDO"></span>
                                </p>
                            </label>
                        </div>
                    </div>
                    @endauth
                </div>
            </div>
        </div><!-- end card -->
        <div class="card light">
            <div class="card-body">
                <h4 class="text-dark mb-3 mt-0 fw-bold">Beli!</h4>
                <div class="row">
                    <div class="col-12">
                        <div class="mb-3">
                            <input type="number" class="form-control" placeholder="Nomor HP ( 628xxxxx )" name="nomor">
                        </div>
                        <div class="mb-3">
                            <input type="email" class="form-control" placeholder="Masukkan Email Anda" name="email">
                        </div>
                        <div class="mb-3">
                            <div class="g-recaptcha" data-sitekey="{{ ENV('CAPTCHA_SITE_KEY') }}"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- end card -->
        <button id="order" class="col-12 btn btn-primary btn-lg btn-block mb-3" type="button">Beli Sekarang</button>
    </div><!-- end col -->
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#nomorTarget").keyup(function() {
            $.ajax({
                url: "<?php echo route('ajax.layanan.ppob') ?>",
                dataType: "json",
                type: "POST",
                data: {
                    "_token": "<?php echo csrf_token() ?>",
                    "target": $("#nomorTarget").val(),
                },
                beforeSend: function() {
                    $("#listLayanan").empty()
                    $("#listLayanan").append("<div class='spinner-border text-primary m-2' role='status'>" +
                        "<span class='visually-hidden'>Loading...</span>" +
                        "</div>")
                },
                success: function(res) {
                    $("#listLayanan").empty()
                    if (res.status) {
                        $("#listLayanan").html(res.data);
                        $("#nama").val(res.nama);
                        $("#daya").val(res.daya);
                    } else {
                        $("#listLayanan").append(`<h3 class='text-muted'>${res.data}</h3>`)
                    }
                    $("input[type=radio][name=nominal]").change(function() {
                        nominal = $("input[type=radio][name=nominal]:checked").val();
                        if (nominal) {
                            $.ajax({
                                url: "<?php echo route("ajax.price.ppob") ?>",
                                dataType: "json",
                                type: "POST",
                                data: {
                                    "_token": "<?php echo csrf_token() ?>",
                                    "nominal": nominal,
                                },
                                success: function(res) {
                                    $("#OVO").html(res.harga);
                                    $("#GOPAY").html(res.harga);
                                    $("#PERMATA").html(res.harga);
                                    $("#CIMBVA").html(res.harga);
                                    $("#BSIVA").html(res.harga);
                                    $("#BNI").html(res.harga);
                                    $("#BRI").html(res.harga);
                                    $("#MANDIRI").html(res.harga);
                                    $("#BCA").html(res.harga);
                                    $("#ALFAMART").html(res.harga);
                                    $("#INDOMARET").html(res.harga);
                                    $("#ALFAMIDI").html(res.harga);
                                    $("#MANDIRIVA").html(res.harga);
                                    $("#OVOS").html(res.harga);
                                    $("#QRIS").html(res.harga);
                                    $("#MYBVA").html(res.harga);
                                    $("#SMSVA").html(res.harga);
                                    $("#MUAMALATVA").html(res.harga);
                                    $("#DANAMONVA").html(res.harga);
                                    $("#BSS").html(res.harga);
                                    $("#LINKAJA").html(res.harga);
                                    $("#SHOPEEPAY").html(res.harga);
                                    $("#SALDO").html(res.harga);
                                }
                            }) //end ajax price
                        }
                    }); //End nominal change                   
                }
            }) //end ajax get layanan          
        }) // end nomor hp keyup

        $("#order").on("click", function() {
            var nomorTarget = $("#nomorTarget").val();
            var service = $("input[name='nominal']:checked").val();
            var pembayaran = $("input[name='pembayaran']:checked").val();
            var nomor = $("input[name='nomor']").val();
            var email = $("input[name='email']").val();
            $.ajax({
                url: "<?php echo route('ajax.confirm-data.ppob') ?>",
                dataType: "JSON",
                type: "POST",
                data: {
                    '_token': '<?php echo csrf_token(); ?>',
                    'nomorTarget': nomorTarget,
                    'service': service,
                    'payment_method': pembayaran,
                    'nomor': nomor,
                    'captcha': grecaptcha.getResponse(),
                    'email': email
                },
                beforeSend: function() {
                    Swal.fire({
                        icon: "info",
                        title: "Mohon Tunggu",
                        background: '#222831',
                        color: '#fff',
                        showConfirmButton: false,
                        allowOutsideClick: false,
                    });
                },
                success: function(res) {
                    if (res.status == true) {
                        Swal.fire({
                            background: '#222831',
                            color: '#fff',
                            titleText: 'Data Pembeli',
                            html: `${res.data}`,
                            showCancelButton: true,
                            confirmButtonText: 'Lanjutkan Pembelian',
                            cancelButtonText: 'Batal',
                            customClass: {
                                title: 'swal-title',
                                htmlContainer: 'swal-text'
                            }

                        }).then(resp => {
                            if (resp.isConfirmed) {
                                var nohp = $("input[name='nomor']").val();
                                var email = $("input[name='email']").val();
                                $.ajax({
                                    url: "<?php echo route('pembelian.ppob') ?>",
                                    dataType: "JSON",
                                    type: "POST",
                                    data: {
                                        '_token': '<?php echo csrf_token() ?>',
                                        'nomorTarget': nomorTarget,
                                        'service': service,
                                        'payment_method': pembayaran,
                                        'nomor': nohp,
                                        'email': email

                                    },
                                    success: function(resOrder) {
                                        if (resOrder.status) {
                                            Swal.fire({
                                                title: 'Berhasil memesan!',
                                                text: `Order ID : ${resOrder.order_id}`,
                                                icon: 'success',
                                                background: '#222831',
                                                color: '#fff'
                                            });
                                            window.location = `/pembelian/invoice/${resOrder.order_id}`;
                                        } else {
                                            Swal.fire({
                                                title: 'Oops...',
                                                text: `${resOrder.data}`,
                                                icon: 'error',
                                                background: '#222831',
                                                color: '#fff'
                                            });
                                        }
                                    }
                                })
                            }
                        })
                    } else if (res.status == false) {
                        Swal.fire({
                            title: 'Oops...',
                            text: res.data,
                            icon: 'error',
                            background: '#222831',
                            color: '#fff'
                        });
                    } else {
                        Swal.fire({
                            title: 'Oops...',
                            text: 'User ID tidak ditemukan.',
                            icon: 'error',
                            background: '#222831',
                            color: '#fff'
                        });
                    }
                },
                error: function(e) {
                    if (e.status == 422) {
                        Swal.fire({
                            title: 'Oops...',
                            text: 'Pastikan anda sudah mengisi semua data yang diperlukan.',
                            icon: 'error',
                            background: '#222831',
                            color: '#fff'
                        });
                    }
                }
            })
        })
    })
</script>
@endsection