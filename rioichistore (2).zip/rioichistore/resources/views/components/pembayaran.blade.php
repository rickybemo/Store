@extends('../main')

@section('content')
<div class="container-fluid">
  <div class="checkout-tabs">
  <div class="row">
  <div class="col-lg-2">
  <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
  <a href="{{ url('about') }}" class="nav-link ">
  <i class="fas fa-address-card d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Tentang Kami</p>
  </a>
  <a href="{{ url('contact') }}" class="nav-link">
  <i class="fas fa-address-book d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Kontak Kami</p>
  </a>
  <a href="{{ url('pembayaran') }}" class="nav-link active">
  <i class="fas fa-tags d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">Pembayaran</p>
  </a>
  <a href="{{ url('faq') }}" class="nav-link">
  <i class="bx bx-question-mark d-block check-nav-icon mt-4 mb-2"></i>
  <p class="fw-bold mb-4">FAQ</p>
  </a>
  </div>
  </div>
  <div class="col-lg-10">
    <div class="card">
    <div class="card-body">
    <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-gen-ques" role="tabpanel" aria-labelledby="v-pills-gen-ques-tab">
    <h4 class="card-title mb-5">Pembayaran yang Tersedia</h4>
    <div class="row">
    <div class="col-md-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <a class="nav-link mb-2 active" id="v-pills-home-tab" data-bs-toggle="pill" href="#transfer-bank" role="tab" aria-controls="v-pills-home" aria-selected="true">Transfer Bank</a>
    
     <a class="nav-link mb-2" id="v-pills-home-tab" data-bs-toggle="pill" href="#virtual-account" role="tab" aria-controls="v-pills-home" aria-selected="true">Virtual Account</a>
    <a class="nav-link mb-2" id="v-pills-home-tab" data-bs-toggle="pill" href="#convenience-store" role="tab" aria-controls="v-pills-home" aria-selected="true">Convenience Store</a>
    <a class="nav-link mb-2" id="v-pills-home-tab" data-bs-toggle="pill" href="#e-wallet" role="tab" aria-controls="v-pills-home" aria-selected="true">E-Wallet</a>
    <a class="nav-link mb-2" id="v-pills-home-tab" data-bs-toggle="pill" href="#saldo" role="tab" aria-controls="v-pills-home" aria-selected="true">Saldo</a>
    </div>
    </div>
    <div class="col-md-9">
    <div class="tab-content text-muted mt-4 mt-md-0" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="transfer-bank" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <div class="channel-grid">
    <div class="channel">
    <img src="{{ asset('assets/img/payment/bca.png') }}">
    <b>BANK BCA
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/bni.png') }}">
    <b>BANK BNI
    
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/bri.png') }}">
    <b>BANK BRI
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/mandiri.png') }}">
    <b>BANK MANDIRI
    </b>
    </div>
    </div>
    </div>
    <div class="tab-pane fade show" id="virtual-account" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <div class="channel-grid">
     <div class="channel">
    <img src="{{ asset('assets/img/payment/maybankva.png') }}">
    <b>Maybank Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/permatava.png') }}">
    <b>Permata Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/bniva.png') }}">
    <b>BNI Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/briva.png') }}">
    <b>BRI Virtual Account
     <br>Fee : Rp 4.250
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/mandiriva.png') }}">
    <b>Mandiri Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/sinarmasva.png') }}">
    <b>Sinarmas Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/muamalatva.png') }}">
    <b>Muamalat Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
     <div class="channel">
    <img src="{{ asset('assets/img/payment/sampoernava.png') }}">
    <b>Sahabat Sampoerna Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/bsiva.png') }}">
    <b>BSI Virtual Account
    <br>Fee : Rp 4.250
    </b>
    </div>
    </div>
    </div>
    <div class="tab-pane fade show" id="convenience-store" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <div class="channel-grid">
     <div class="channel">
    <img src="{{ asset('assets/img/payment/alfamart.png') }}">
    <b>Alfamart
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/indomaret.png') }}">
    <b>Indomaret
    </b>
    </div>
    <div class="channel">
    <img src="{{ asset('assets/img/payment/alfamidi.png') }}">
    <b>Alfamidi
    </b>
    </div>
    </div>
    </div>
    <div class="tab-pane fade show" id="e-wallet" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <div class="channel-grid">
    <div class="channel">
     <img src="{{ asset('assets/img/payment/qris.png') }}">
    <b>QRIS
    </b>
    </div>
    </div>
    </div>
    <div class="tab-pane fade show" id="saldo" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <div class="channel-grid">
    <div class="channel">
    <img src="{{ asset('assets/img/payment/saldo-akun.png') }}">
    <b>Saldo
    </b>
     </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
  </div>
  </div>
  </div>
@endsection('content')