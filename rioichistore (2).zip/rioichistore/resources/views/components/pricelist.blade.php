@extends("main")

@section("content")
<div class="container-fluid">
    <div class="row">
    <div class="col-12">
    <div class="card">
    <div class="card-body">
    <h4 class="card-title">Daftar Harga</h4>
    <div class="mb-3 col-lg-2">
    <label>Pilih Game</label>
    <select name="game" id="game" class="form-select">
    <option selected>All</option>
    @foreach($kategoris as $category)
        <option value="{{ $category->id }}">{{ $category->nama }}</option>
    @endforeach
    </select>
    </div>
    <div class="table-responsive">
    <table id="table-data" class="table table-bordered nowrap w-100">
    <thead>
    <tr>
    <th>Product</th>
    <th>Nama </th>
    <th>Harga Publik</th>
    <th>Harga Gp;d</th>
    <th>Harga Platinum</th>
    <th>Status</th>
    </tr>
    </thead>
    <tbody>
        
    </tbody>
    </table>
    </div>
    </div>
    </div>
    </div> 
    </div> 

    @push('script-lib')
    <script type="text/javascript">
        mybutton = document.querySelector(".act-btn-top");
        window.onscroll = function() {
            scrollFunc()
        };
    
        function scrollFunc() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                mybutton.style.display = "block";
            } else {
                mybutton.style.display = "none";
            }
        }
    
        function toTop() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>
    <script>
            fill_datatable();
                function fill_datatable(filter_game = '')
                {
                    var t = $('#table-data').DataTable({
                        processing: true,
                        serverSide: false,
                        scrollX: true,
                        "order":[ 
                            [0, "asc"],
                            [1, "asc"],
                            [2, "asc"],
                            [3, "asc"],
                        ],
    
                        ajax:{
                            url: "{{ route('prices') }}",
                            data: 
                            {
                                filter_game:filter_game,
                            }
                        },
                    columnDefs:[
                        {targets: '_all', visible: true},
                            {
                                "targets": 0,
                                data: "nama_kategori",
                                name: "nama_kategori"
                            },
                            {
                                "targets": 1,
                                data: "layanan",
                                name: "layanan"
                            },
                            {
                                "targets": 2,
                                data: 'harga',
                                name: 'harga',
                                render: $.fn.dataTable.render.number( '.', ',', 0, 'Rp. ' )
    
                            },
                            {
                                "targets": 3,
                                data: 'harga_reseller',
                                name: 'harga_reseller',
                                render: $.fn.dataTable.render.number( '.', ',', 0, 'Rp. ' )
    
                            },
                            {
                                "targets": 4,
                                data: 'harga_vip',
                                name: 'harga_vip',
                                render: $.fn.dataTable.render.number( '.', ',', 0, 'Rp. ' )
    
                            },
                            {
                                "targets": 5,
                                data: 'status',
                                name: 'status'
                            }
                    ],
    
                })
                }
                $("#game").change(function() {
                    var filter_game = $(this).val(); 
                    console.log(filter_game)
                    if(filter_game != '')
                    {
                        $('#table-data').DataTable().destroy();
                        fill_datatable(filter_game);
                    }
                });
        </script>
    @endpush
@endsection