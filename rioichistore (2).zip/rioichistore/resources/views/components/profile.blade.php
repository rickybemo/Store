@extends("main")

@section("content")
<div class="wrapper pt-4 pb-4 bangjeffbgblack">
   <div class="container mb-5">
      <div class="row">
         <div class="col-12 col-lg-3 mx-auto mt-5">
            <div class="card shadow bg-white">
               <div class="card-body">
                  <div class="row">
                     <div class="col-12 text-center">
                        
                     </div>
                  </div>
                  <hr>
                  <dl>
                     <table style="font-size:12px;">
                          <tr>
                           <th>Nama</th>
                           <td>: {{ Auth::user()->name }}</td>
                        <tr>
                        <tr>
                           <th>Username</th>
                           <td>: {{ Auth::user()->username }}</td>
                        <tr>
                           <th>Saldo</th>
                           <td>: <span class="badge bg-primary" id="balance" data-bs-toggle="tooltip" data-bs-placement="top" title="Top Up Saldo" onclick="window.location.href = '{{ route('deposit') }}';">Rp. {{ number_format(Auth::user()->balance, 0, ',', '.') }}</span>
                                 <span class="badge bg-primary" id="balance" data-bs-toggle="tooltip" data-bs-placement="top" title="Top Up Saldo" onclick="window.location.href = '{{ route('deposit') }}';">+</span>
                           </td>
                        <tr>
                           <th>Status Akun</th>
                           <td>: {{ Auth::user()->role }}</td>
                           </td>
                     </table>
                  </dl>
                  <div class="strip-primary"></div>
                  <br />
                  <h6 class="text-center">Mau dapat harga yg lebih murah?</h6>
                  <h4 class="text-center">Yuk Join Reseller!</h4>
                  <h2 class="text-center"><span class="badge btn-primary" title="Click to Join Reseller" onclick="window.location.href = '{{ route('upgrade') }}';">Join Now</span></h2>
               </div>
            </div>
         </div>
         <div class="col-12 col-lg-9 mx-auto mt-5">
            <div class="card shadow rounded bg-white">
                <div class="row mt-2">
                    <div class="col-6">
                        <div class="card-body"><span class="h4">History</span></div>
                    </div>
                    <div class="col-6 col-lg-6 mx-auto mt-2">
                        <form action="{{ route('profile') }}" method="get">
                       <div class="input-group search-bar mb-3" aria-haspopup="true" id="dropsearchdown">
                                <input type="text" name="q" placeholder="Ketik layanan.." id="searchProds" class="form-control search_input" autocomplete="off">
                                <button type="submit" class="btn btn-orange" id="btnSearchProds">
                                    <i class="fas fa-search text-dark"></i>
                                </button>
                            </div>
                         </div>
               <div class="card-body">
                  <div class="table-responsive">
                     <table class="table table-striped table-white" id="tblUser" style="font-size: 12px !important;">
                        <thead>
                            <tr>
                                <th>Invoice</th>
                                <th>Layanan</th>
                                <th>Target</th>
                                <th>Harga</th>
                                <th>Status</th>
                                <th>Detail</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($pembelian as $pesanan)
                            @php
                            $zone = $pesanan->zone != null ? "-".$pesanan->zone : "";
                            $label_pesanan = '';
                            if($pesanan->status == "Pending" || $pesanan->status == "Menunggu Pembayaran" || $pesanan->status == "Waiting"){
                            $label_pesanan = 'warning';
                            }else if($pesanan->status == "Processing"){
                            $label_pesanan = 'info';
                            }else if($pesanan->status == "Success"){
                            $label_pesanan = 'success';
                            }else{
                            $label_pesanan = 'danger';
                            }
                            @endphp
                            <tr>
                                <th scope="row">{{ $pesanan->order_id }}</th>
                                <td>
                                    {{ $pesanan->layanan }}<br>
                                </td>
                                <td>{{ $pesanan->user_id.$zone }}</td>
                                <td>Rp. {{ number_format($pesanan->harga, 0, ',', '.') }}</td>
                                <td><span class="badge bg-{{ $label_pesanan }}">{{ $pesanan->status }}</span></td>
                                <td><a href="javascript:;" onclick="modal('Order Details', '{{ route('riwayat.detail', [$pesanan->order_id]) }}')" class="btn btn-info"><i class="fa fa-qrcode"></i></a></td>
                            </tr>
                            @endforeach
                        </tbody>                         
                     </table>
                  </div> 
                  </div> 
                 <div class="d-flex justify-content-center">
                    {{ $pembelian->links('vendor.pagination.simple-tailwind') }}
                  </div>

               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<script type="text/javascript">
    function modal(name, link) {
        // var myModal = new bootstrap.Modal($('#modal-detail'))
        $.ajax({
            type: "GET",
            url: link,
            beforeSend: function() {
                $('#modal-detail-title').html(name);
                $('#modal-detail-body').html('Loading...');
            },
            success: function(result) {
                $('#modal-detail-title').html(name);
                $('#modal-detail-body').html(result);
            },
            error: function() {
                $('#modal-detail-title').html(name);
                $('#modal-detail-body').html('There is an error...');
            }
        });
        $("#modal-detail").modal("show");
    }
</script>

<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" id="modal-detail" style="border-radius:7%">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-white">
            <div class="modal-header">
                <h4 class="modal-title" id="modal-detail-title"></h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modal-detail-body"></div>
        </div>
    </div>
</div>
@endsection