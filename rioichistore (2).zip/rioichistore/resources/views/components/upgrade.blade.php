@extends('main')

@section('content')
    <div class="wrapper pt-4 pb-4 bangjeffbgblack">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto mt-5">
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                    <div class="card bg-white shadow">
                        <form action="{{ route('upgrade.role') }}" method="POST">
                            <div class="card-header">
                                <h5>Join Reseller</h5>
                            </div>
                            <div class="card-body">
                                <h4>Akun Anda saat Ini : <strong id="currentRole"
                                        class="badge bg-success badge-pill">{{ Auth::user()->role }}</strong></h4>
                                <span class="badge btn-primary" title="Click to Join Reseller"
                                    onclick="window.location.href = '{{ route('price') }}';">Klik Disini</span>
                                <span style="font-size: 13px"> untuk melihat daftar harga reseller</span>
                                <hr>
                                <h5>Upgrade Akun ke :</h5>
                                @csrf
                                <div class="list-group list-group-numbered">
                                    @if (Auth::user()->role == 'Member')
                                        <label
                                            class="list-group-item bg-white text-dark d-flex justify-content-between align-items-start">
                                            <input type="radio" class="form-check-input me-1" name="role"
                                                id="role" value="Gold">
                                            <div class="ms-2 me-auto">
                                                <div class="fw-bold">Gold</div>
                                                Reseller Gold untuk pedagang kecil mendapat diskon murah
                                            </div>

                                            <span class="badge bg-primary rounded-pill">Rp 99.000</span>
                                        </label>
                                        <label
                                            class="list-group-item bg-white text-dark d-flex justify-content-between align-items-start">
                                            <input type="radio" class="form-check-input me-1" name="role"
                                                id="role" value="Platinum">
                                            <div class="ms-2 me-auto">
                                                <div class="fw-bold">Platinum</div>
                                                Reseller Platinum untuk pedagang besar mendapat diskon paling murah
                                            </div>
                                            <span class="badge bg-primary rounded-pill">Rp 199.000</span>
                                        </label>
                                    @elseif(Auth::user()->role == 'Gold')
                                        <label
                                            class="list-group-item bg-white text-dark d-flex justify-content-between align-items-start">
                                            <input type="radio" class="form-check-input me-1" name="role"
                                                id="role" value="Platinum">
                                            <div class="ms-2 me-auto">
                                                <div class="fw-bold">Platinum</div>
                                                Reseller Platinum untuk pedagang besar mendapat diskon paling murah
                                            </div>
                                            <span class="badge bg-primary rounded-pill">Rp 199.000</span>
                                        </label>
                                    @endif
                                </div>
                                <hr>
                            </div>
                            <div class="card-footer">
                                <button class="btn btn-primary w-100 btn-lg">
                                    <div class="fas fa-shopping-basket"></div>
                                    Upgrade Now
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        // if radio button is checked
        $(document).ready(function() {
            $('input[type="radio"]').click(function() {
                if ($(this).attr("id") == "role") {
                    //   $("#currentRole").text($(this).val());
                    $(this).parent().addClass("active");
                    // remove class from siblings
                    $(this).parent().siblings().removeClass("active");
                }
            });
        });
    </script>
@endsection
