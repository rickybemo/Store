@extends('main-admin')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <h4 class="page-title">Konfigurasi Wa Sender</h4>
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item active">/konfigurasi/wasend</li>
                </ol>
            </div>
        </div>
    </div>
</div>
@if(session('error'))
<div class="alert alert-danger">
    {{ session('error') }}
</div>
@elseif(session('success'))
<div class="alert alert-success">
    {{ session('success') }}
</div>
@endif
<div class="card">
    <div class="card-body">
        <h4 class="mb-3 header-title mt-0">Konfig</h4>
        <form action="{{ url('wasend/change') }}" method="POST">
            @csrf
            <div class="form-group">
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label" for="example-fileinput">Key</label>
                    <div class="col-lg-10">
                        <input type="text" name="key" id="key" @if (isset($wasend->key))
                        value="{{ $wasend->key }}"
                        @else
                        value="{{ old('key') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label">Number</label>
                    <div class="col-lg-10">
                        <input type="text" name="number" id="number" @if (isset($wasend->number))
                        value="{{ $wasend->number }}"
                        @else
                        value="{{ old('number') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label class="col-lg-2 col-form-label">API Url</label>
                    <div class="col-lg-10">
                        <input type="url" name="api_url" id="api_url" @if (isset($wasend->api_url))
                        value="{{ $wasend->api_url }}"
                        @else
                        value="{{ old('Url API kamu: https://api.wa.me') }}"

                        @endif
                        class="form-control">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>
@endsection